# به‌روزرسانی ظاهر
این ZIP فقط رابط وب و فونت‌های ارسالی مالک را دارد.
محتوا را داخل پوشه فعلی پروژه استخراج و فایل‌های هم‌نام را جایگزین کنید؛ پوشه apps داخل ZIP باید با apps پروژه ادغام شود.
در PowerShell همان پوشه اجرا کنید:

```powershell
docker compose build api
if ($LASTEXITCODE -eq 0) {
    docker compose up -d --no-build --wait api worker web
}
```
سپس مرورگر را با Ctrl+F5 تازه کنید. این بسته فایل .env، دیتابیس و تنظیمات اتصال را تغییر نمی‌دهد.
