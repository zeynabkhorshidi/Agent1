export type Entity={id:string;kind:string;status:string;version:number;created_at:string;store_id:string|null;data:Record<string,any>};
export type Product={id:string;code:string;name:string;barcode:string;pack:number;price_rial:number;provenance:Record<string,any>};
let csrf=''; export function setCSRF(v:string){csrf=v}
export async function api(path:string,method='GET',body?:unknown,headers:Record<string,string>={}){
 const form=body instanceof FormData;
 const r=await fetch('/api/v1'+path,{method,credentials:'same-origin',headers:{...(!form?{'Content-Type':'application/json'}:{}),...(method!=='GET'?{'X-CSRF-Token':csrf}:{}),...headers},body:body===undefined?undefined:form?body:JSON.stringify(body)});
 const d=await r.json(); if(!r.ok)throw new Error(d.message||'ارتباط با سرور برقرار نشد'); return d;
}
