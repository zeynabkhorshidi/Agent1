import asyncio, json, hashlib, secrets, time, os, logging
from datetime import date, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, Depends, Request, Response, UploadFile, File, Header
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import select, func, text
from packages.domain.core import *
from packages.domain.routing import plan, coalition
from packages.integrations.catalog import preview, commit_import
from packages.integrations.providers import VTTGateway

app=FastAPI(title='بازار عامل‌های سایه‌سمن',version='1.0.0',openapi_url='/api/v1/openapi.json',docs_url='/api/v1/docs')
logging.basicConfig(level=logging.INFO)
log=logging.getLogger('api')
rate={}
def db_session():
    with DB() as db:
        try: yield db; db.commit()
        except: db.rollback(); raise

def auth(request:Request,db=Depends(db_session,scope="function")):
    token=request.cookies.get('session',''); s=db.get(Session,hashlib.sha256(token.encode()).hexdigest())
    if not s or s.expires<now(): fail('UNAUTHORIZED','لطفاً وارد سامانه شوید',401)
    u=db.get(User,s.user_id)
    if not u: fail('UNAUTHORIZED','کاربر یافت نشد',401)
    if request.method not in ('GET','HEAD','OPTIONS') and request.url.path not in ('/api/v1/auth/logout',):
        if request.headers.get('X-CSRF-Token')!=token: fail('CSRF','درخواست معتبر نیست',403)
    return u

def query(db,u,kind):
    stmt=select(Record).where(Record.kind==kind,Record.tenant==u.tenant,Record.branch==u.branch)
    if u.role=='customer': stmt=stmt.where(Record.store_id==u.store_id)
    return stmt

def get_record(db,u,rid,kind=None,lock=False):
    stmt=select(Record).where(Record.id==rid)
    if lock: stmt=stmt.with_for_update()
    r=db.scalar(stmt)
    if not r or (kind and r.kind!=kind): fail('NOT_FOUND','پرونده یافت نشد',404)
    scope(u,r); return r

def serialize(r): return {'id':r.id,'kind':r.kind,'status':r.status,'version':r.version,'created_at':r.created_at,'store_id':r.store_id,'data':r.data}

@app.middleware('http')
async def headers(request,call_next):
    start=time.monotonic(); cid=secrets.token_hex(12)
    try:
        if os.getenv('APP_MODE','demo')!='demo' and request.method not in ('GET','HEAD','OPTIONS') and not request.url.path.startswith('/api/v1/auth/'):
            return JSONResponse({'error_code':'MODE_DISABLED','message':'این نصب فقط دفتر جداگانه دمو را پشتیبانی می‌کند؛ نوشتن حالت‌های دیگر فعال نیست'},403)
        response=await call_next(request)
    except Exception:
        log.exception('request_failed correlation_id=%s',cid)
        response=JSONResponse({'error_code':'INTERNAL','message':'خطای داخلی؛ شناسه پیگیری را به پشتیبانی بدهید'},500)
    response.headers.update({'X-Correlation-ID':cid,'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'"})
    log.info(json.dumps({'method':request.method,'path':request.url.path,'status':response.status_code,'duration_ms':round((time.monotonic()-start)*1000),'correlation_id':cid}))
    return response
@app.exception_handler(DomainError)
async def domain_error(request,e): return JSONResponse({'error_code':e.code,'message':e.message},e.status)
@app.exception_handler(RequestValidationError)
async def validation_error(request,e): return JSONResponse({'error_code':'VALIDATION','message':'ورودی معتبر نیست؛ نوع و محدوده فیلدها را بررسی کنید','fields':['.'.join(map(str,x['loc'])) for x in e.errors()]},422)

class Strict(BaseModel): model_config=ConfigDict(extra='forbid')
class Login(Strict): username:str=Field(max_length=80); password:str=Field(max_length=200)
@app.post('/api/v1/auth/login')
def login(body:Login,request:Request,response:Response,db=Depends(db_session,scope="function")):
    host=request.client.host if request.client else 'unknown'; cutoff=time.monotonic()-60; attempts=[t for t in rate.get(host,[]) if t>cutoff]; rate[host]=attempts
    if len(attempts)>=10: fail('RATE_LIMIT','تلاش زیاد؛ یک دقیقه بعد دوباره امتحان کنید',429)
    attempts.append(time.monotonic()); u=db.get(User,body.username)
    if not u or not password_check(body.password,u.password): fail('LOGIN_FAILED','نام کاربری یا رمز نادرست است',401)
    token=secrets.token_urlsafe(32); db.add(Session(id=hashlib.sha256(token.encode()).hexdigest(),user_id=u.id,expires=(datetime.now(timezone.utc)+timedelta(hours=8)).isoformat()))
    response.set_cookie('session',token,httponly=True,secure=os.getenv('COOKIE_SECURE')=='true',samesite='strict',max_age=28800)
    return {'csrf_token':token,'user':{'id':u.id,'role':u.role,'store_id':u.store_id}}
@app.get('/api/v1/auth/me')
def me(request:Request,u=Depends(auth)): return {'user':{'id':u.id,'role':u.role,'store_id':u.store_id},'csrf_token':request.cookies['session']}
@app.post('/api/v1/auth/logout')
def logout(request:Request,response:Response,u=Depends(auth),db=Depends(db_session,scope="function")):
    s=db.get(Session,hashlib.sha256(request.cookies['session'].encode()).hexdigest()); db.delete(s); response.delete_cookie('session'); return {'status':'ok'}
@app.get('/api/v1/health/live')
def live(): return {'status':'ok','mode':os.getenv('APP_MODE','demo')}
@app.get('/api/v1/health/ready')
def ready(db=Depends(db_session,scope="function")):
    db.execute(text('SELECT 1'))
    if not db.get(Setting,'seed'): fail('NOT_SEEDED','داده اولیه آماده نیست',503)
    return {'status':'ready','database':engine.dialect.name,'mode':os.getenv('APP_MODE','demo')}
@app.get('/api/v1/dashboard')
def dashboard(u=Depends(auth),db=Depends(db_session,scope="function")):
    counts={k:len(db.scalars(query(db,u,k)).all()) for k in ['order','proposal','run','intent']}
    return {'counts':counts,'source':'demo-ledger','observed_at':now(),'synthetic':True,'mode':os.getenv('APP_MODE','demo'),'control':db.get(Setting,'control').value}
@app.get('/api/v1/catalog/products')
def products(q:str='',page:int=1,page_size:int=20,u=Depends(auth),db=Depends(db_session,scope="function")):
    if page<1 or not 1<=page_size<=100: fail('PAGE','صفحه نامعتبر',422)
    rows=db.scalars(select(Product).where(Product.tenant==u.tenant).order_by(Product.code)).all(); term=normalize(q)
    rows=[p for p in rows if term in normalize(p.name+' '+p.code+' '+p.barcode)]
    return {'total':len(rows),'page':page,'items':[{'id':p.id,'code':p.code,'name':p.name,'barcode':p.barcode,'pack':p.pack,'price_rial':p.price,'version':p.version,'provenance':p.provenance} for p in rows[(page-1)*page_size:page*page_size]]}
@app.get('/api/v1/records/{kind}')
def records(kind:str,u=Depends(auth),db=Depends(db_session,scope="function")):
    allowed={'store','intent','proposal','approval','order','run','route','warehouse','vehicle','mandate','experiment','import'}
    if kind not in allowed: fail('FORBIDDEN','این فهرست قابل مشاهده نیست',403)
    if u.role=='customer' and kind in {'warehouse','vehicle','import','experiment','route'}: fail('FORBIDDEN','دسترسی مجاز نیست',403)
    if kind in {'import','experiment'}: permit(u,'admin','sales','viewer')
    return [serialize(r) for r in db.scalars(query(db,u,kind).order_by(Record.created_at.desc()).limit(100))]
@app.get('/api/v1/inventory')
def inventory(u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin','warehouse','sales')
    return [{'id':s.id,'sku':s.sku,'warehouse':s.warehouse,'batch':s.batch,'expiry':s.expiry,'on_hand':s.on_hand,'reserved':s.reserved,'available':s.on_hand-s.reserved,'quarantine':s.quarantine,'version':s.version} for s in db.scalars(select(Stock).where(Stock.tenant==u.tenant,Stock.branch==u.branch))]
class Line(Strict):
    sku:str; quantity:int=Field(ge=1,le=10000,strict=True); unit:Literal['each','carton']
class IntentInput(Strict):
    store_id:str; text:str=Field(max_length=4000); lines:list[Line]=Field(max_length=30); budget_rial:int=Field(ge=0,le=10**15,strict=True); delivery_day:date
@app.post('/api/v1/purchase-intents')
def create_intent(body:IntentInput,u=Depends(auth),db=Depends(db_session,scope="function")):
    writable(db,u); store=get_record(db,u,body.store_id,'store')
    if body.delivery_day<datetime.now(ZoneInfo("Asia/Tehran")).date(): fail('DATE','روز تحویل گذشته است',422)
    r=record(db,u,'intent',body.model_dump(mode='json'),'draft',store.id); event(db,u,'IntentCreated',r); return serialize(r)
@app.post('/api/v1/purchase-intents/{rid}/validate')
def validate(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")):
    r=get_record(db,u,rid,'intent',True); validate_intent(db,u,r); return serialize(r)
class RunInput(Strict): intent_id:str; provider:Literal['demo','live']='demo'
@app.post('/api/v1/agent-runs')
def run(body:RunInput,u=Depends(auth),db=Depends(db_session,scope="function")):
    writable(db,u); intent=get_record(db,u,body.intent_id,'intent')
    if intent.status!='validated': fail('STATE','درخواست اعتبارسنجی نشده است')
    r=record(db,u,'run',{'actor':u.id,**body.model_dump()},'queued',intent.store_id); event(db,u,'AgentRunQueued',r); return serialize(r)
@app.get('/api/v1/agent-runs/{rid}')
def run_get(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")): return serialize(get_record(db,u,rid,'run'))
@app.post('/api/v1/agent-runs/{rid}/cancel')
def run_cancel(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")):
    writable(db,u); r=get_record(db,u,rid,'run',True)
    if r.status not in ('queued','running'): fail('STATE','اجرای پایان‌یافته قابل توقف نیست')
    r.status='cancelled'; r.version+=1; event(db,u,'AgentRunCancelled',r); return serialize(r)
class Decision(Strict): expected_version:int; terms_hash:str; approve:bool
@app.post('/api/v1/approvals/{rid}/decide')
def decide(rid:str,b:Decision,u=Depends(auth),db=Depends(db_session,scope="function")):
    writable(db,u); r=get_record(db,u,rid,'approval',True); p=get_record(db,u,r.data['proposal_id'],'proposal',True)
    if r.status!='pending' or r.version!=b.expected_version or r.data['terms_hash']!=b.terms_hash or p.status!='awaiting_approval' or p.data['expires']<now(): fail('VERSION','تأیید معتبر نیست یا منقضی شده است')
    r.status='approved' if b.approve else 'rejected'; r.version+=1; event(db,u,'ApprovalDecided',r); return serialize(r)
class Accept(Strict): expected_version:int; terms_hash:str
@app.post('/api/v1/proposals/{rid}/accept')
def accept_proposal(rid:str,b:Accept,idempotency_key:str=Header(),u=Depends(auth),db=Depends(db_session,scope="function")):
    return accept(db,u,rid,b.expected_version,b.terms_hash,idempotency_key)
@app.post('/api/v1/proposals/{rid}/reject')
def reject(rid:str,b:Accept,u=Depends(auth),db=Depends(db_session,scope="function")):
    writable(db,u); r=get_record(db,u,rid,'proposal',True)
    if r.status!='awaiting_approval' or r.version!=b.expected_version or r.data['terms_hash']!=b.terms_hash: fail('VERSION','نسخه معتبر نیست')
    r.status='rejected'; r.version+=1; event(db,u,'ProposalRejected',r); return serialize(r)
@app.get('/api/v1/orders/{rid}')
def order_get(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")): return serialize(get_record(db,u,rid,'order'))
class Transition(Strict): expected_version:int; target:Literal['dispatched','delivered','cancelled']
@app.post('/api/v1/orders/{rid}/transition')
def transition(rid:str,b:Transition,u=Depends(auth),db=Depends(db_session,scope="function")):
    r=get_record(db,u,rid,'order',True)
    if r.version!=b.expected_version: fail('VERSION','نسخه سفارش تغییر کرده است')
    if b.target=='cancelled': writable(db,u); release(db,u,r,'cancelled')
    else: fulfill(db,u,r,b.target)
    return serialize(r)
class Economics(Strict): baseline_rial:int=Field(ge=0); grouped_rial:int=Field(ge=0); handling_rial:int=Field(ge=0,default=0); ai_rial:int=Field(ge=0,default=0)
@app.post('/api/v1/coalitions/evaluate')
def evaluate(b:Economics,u=Depends(auth)):
    permit(u,'admin','sales'); return coalition(b.baseline_rial,b.grouped_rial,b.handling_rial,b.ai_rial)
class RouteInput(Strict): store_ids:list[str]=Field(min_length=1,max_length=100); excluded_vehicle_ids:list[str]=[]
@app.post('/api/v1/routes/plan')
def route_plan(b:RouteInput,u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin','sales','warehouse')
    stores=[serialize(get_record(db,u,i,'store')) for i in dict.fromkeys(b.store_ids)]
    vehicles=[serialize(r) for r in db.scalars(query(db,u,'vehicle').where(Record.status=='active')) if r.id not in b.excluded_vehicle_ids]
    depot=db.scalar(query(db,u,'warehouse')); result=plan(stores,vehicles,depot.data)
    r=record(db,u,'route',result,'planned'); event(db,u,'RouteReplanned',r,{'distance_m':result.get('distance_m'),'unserved':result['unserved']}); return serialize(r)
@app.get('/api/v1/integrations/health')
def integrations(u=Depends(auth)):
    return [{'id':k,'status':s,'message':m} for k,s,m in [('demo','ready','دفتر محلی با داده مصنوعی'),('llm','unconfigured','مدل زنده و هزینه آن تأیید نشده'),('vtt','unverified','قرارداد پروتکل، کدک و احراز هویت لازم است'),('erp','disconnected','قرارداد و داده رسمی شرکت لازم است'),('map','demo-only','جدول و هندسه تقریبی محلی فعال است'),('catalog','unverified','نمونه سند؛ استخراج آنلاین تأیید نشده')]]
@app.post('/api/v1/voice/sessions')
def voice(u=Depends(auth)): return VTTGateway().create_session()
@app.post('/api/v1/catalog/imports')
async def import_upload(file:UploadFile=File(),u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin'); content=await file.read(2_000_001); result=preview(content,file.filename or '')
    old=db.scalars(query(db,u,'import')).all(); match=next((r for r in old if r.data['hash']==result['hash']),None)
    if match:return serialize(match)
    r=record(db,u,'import',result,'preview'); event(db,u,'ImportPreviewed',r,{'hash':result['hash'],'count':result['row_count']}); return serialize(r)
@app.get('/api/v1/catalog/imports/{rid}')
def import_get(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin'); return serialize(get_record(db,u,rid,'import'))
@app.post('/api/v1/catalog/imports/{rid}/commit')
def import_commit(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin'); writable(db,u); return serialize(commit_import(db,u,get_record(db,u,rid,'import',True)))
class Control(Strict): kill_switch:bool; name:str=Field(min_length=1,max_length=120)
@app.put('/api/v1/settings')
def control(b:Control,u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin'); s=db.get(Setting,'control'); s.value=b.model_dump(); r=record(db,u,'control',b.model_dump(),'updated'); event(db,u,'ControlUpdated',r); return s.value
@app.post('/api/v1/mandates/{rid}/revoke')
def revoke(rid:str,u=Depends(auth),db=Depends(db_session,scope="function")):
    permit(u,'admin','customer'); r=get_record(db,u,rid,'mandate',True); r.status='revoked'; r.version+=1; event(db,u,'MandateRevoked',r); return serialize(r)
@app.get('/api/v1/events')
async def events(request:Request,cursor:int=0,u=Depends(auth),last_event_id:str|None=Header(default=None)):
    try: current=max(cursor,int(last_event_id or 0))
    except ValueError: fail('CURSOR','نشانگر رویداد نامعتبر است',422)
    async def stream():
        nonlocal current
        for _ in range(25):
            if await request.is_disconnected(): break
            with DB() as db:
                stmt=select(Event).where(Event.seq>current,Event.tenant==u.tenant,Event.branch==u.branch).order_by(Event.seq).limit(100)
                if u.role=='customer': stmt=stmt.where(Event.store_id==u.store_id)
                for e in db.scalars(stmt):
                    current=e.seq
                    envelope={'event_id':e.id,'event_type':e.event_type,'schema_version':1,'aggregate_id':e.aggregate_id,'aggregate_version':e.payload.get('version',1),'occurred_at':e.created_at,'tenant_id':e.tenant,'branch_id':e.branch,'correlation_id':e.id,'causation_id':None,'mode':'demo','payload':e.payload}
                    yield f'id: {e.seq}\ndata: {json.dumps(envelope,ensure_ascii=False)}\n\n'
            yield ': heartbeat\n\n'; await asyncio.sleep(1)
    return StreamingResponse(stream(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})
# Serve built frontend after API routes, with SPA fallback.
web=Path(__file__).resolve().parents[2]/'apps/web/dist'
if web.exists():
    from fastapi.responses import FileResponse
    app.mount('/assets',StaticFiles(directory=web/'assets'),name='assets')
    @app.get('/{path:path}')
    def spa(path:str):
        if path.startswith('api/'): fail('NOT_FOUND','مسیر یافت نشد',404)
        return FileResponse(web/'index.html')
