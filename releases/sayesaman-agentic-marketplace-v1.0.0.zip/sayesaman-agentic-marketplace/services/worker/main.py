import time, logging
from sqlalchemy import select
from packages.agents.runner import process_one
from packages.domain.core import *
logging.basicConfig(level=logging.INFO)
def maintenance():
    with DB.begin() as db:
        u=db.get(User,'admin')
        if not u: return
        for r in db.scalars(select(Record).where(Record.kind=='order',Record.status=='confirmed').with_for_update(skip_locked=True)):
            if r.data['reservation_expires']<now(): release(db,u,r)
        for r in db.scalars(select(Record).where(Record.kind=='outbox',Record.status=='pending').with_for_update(skip_locked=True)):
            # This sink never calls a company ERP.
            r.status='acknowledged'; r.data={**r.data,'ack':'demo-ledger-only','acknowledged_at':now()}; event(db,u,'DemoOutboxAcknowledged',r)
if __name__=='__main__':
    while True:
        try:
            if not process_one(): maintenance(); time.sleep(1)
        except Exception:
            logging.exception('worker_iteration_failed'); time.sleep(3)
