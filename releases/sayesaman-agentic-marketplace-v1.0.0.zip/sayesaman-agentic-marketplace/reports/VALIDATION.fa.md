# شواهد اعتبارسنجی
- Python 3.12.14، Node 24.19.0 در اجرای میزبان؛ imageها Python 3.12.12 و Node 22.21.1.
- PostgreSQL 17.6: بیست‌وپنج آزمون هسته/API/worker/امنیت پاس؛ SQLite نیز ۲۵ پاس. چهار warning مربوط به dependency deprecation (AnyIO/SWIG)، نه test skipped. تست live-provider واقعی و مجموعه کامل upstream اجرا نشده‌اند.
- مرورگر Chromium نصب‌شده محیط: مسیر فارسی login→intent→worker→proposal→approval→order→dispatch→delivery، جست‌وجو و RTL دسکتاپ/موبایل پاس؛ صفر uncaught error و بدون overflow افقی موبایل. تصاویر desktop-dashboard، desktop-catalog و mobile-intent همراه بسته‌اند. این بررسی جایگزین audit کامل WCAG نیست.
- TypeScript check و build Vite موفق. Docker image build با TLS و hash verification موفق.
- Compose کامل: PostgreSQL، migrate/seed، API، worker، web؛ HTTP readiness موفق. backup/restore در DB جدا با ۳۰ محصول بازیابی‌شده پاس؛ backup عملیاتی داخل ZIP نیست.
- load مصنوعی: هزار مشتری ذخیره، صد intent، بیست worker هم‌زمان، صد run تکمیل؛ ۲۰۰ درخواست جست‌وجو با concurrency=20، صفر خطا، p50≈166ms و p95≈218ms. سخت‌افزار: پنج CPU در container و ۳۴۰۸۷MB حافظه گزارش‌شده میزبان. تست از TestClient محلی استفاده کرده و ظرفیت شبکه/مدل واقعی را اثبات نمی‌کند.
- benchmark چند seed و شدت اختلال در JSON/CSV؛ C_demo با B بهینه‌ساز مشترک دارد. C_live اجرا نشده و ROI واقعی ناشناخته است.
- خطاهای پیدا و اصلاح‌شده: ورودی نامناسب تست کمبود موجودی، رندر رکورد صفحه قبلی در میز معامله، claim اولیه worker که چند job را قفل می‌کرد. آخرین گزارش‌ها پس از اصلاح تولید شده‌اند.

- بررسی HTTP واقعی پشت Nginx یک race میان پاسخ موفق و commit وابستگی yield پیدا کرد. scope وابستگی DB به function تغییر کرد تا commit پیش از ارسال پاسخ انجام شود؛ بررسی نهایی ZIP و مرورگر پس از این اصلاح تکرار شد.

## به‌روزرسانی ظاهر — ۲۰۲۶/۱۱/۰۷
ایران‌سنس ارسالی مالک با چهار وزن محلی اعمال شد. TypeScript/Vite build و E2E فارسی خرید تا تحویل روی Chromium در دسکتاپ ۱۴۴۰×۱۱۰۰ و موبایل ۳۹۰×۸۴۴ پاس شد. فونت سفارشی واقعاً استفاده‌شده با Chromium CDP تأیید شد و متن‌های قابل مشاهده داشبورد کمتر از ۱۳ پیکسل نیستند. عنوان انگلیسی و برچسب منبع در داشبورد وجود ندارد؛ نمایش آزمایشی بودن محیط باقی است. این تغییر در UI است و آزمون کامل backend دوباره اجرا نشده؛ شواهد قبلی backend مربوط به نسخه قبلی همان هسته است.

Docker image پس از تغییر فونت و ظاهر نیز با موفقیت build شد. بسته UI مستقل شامل فایل‌های frontend و چهار فونت، با manifest هش بررسی شده است.
