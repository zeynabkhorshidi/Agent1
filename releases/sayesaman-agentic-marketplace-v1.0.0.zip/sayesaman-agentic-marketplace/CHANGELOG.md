# تغییرات
## 1.0.0 — ۲۰۲۶/۱۱/۰۳
ایجاد دموی فارسی با domain ledger، تأیید نسخه، رزرو اتمیک، عامل قطعی، آداپتر پیام upstream، UI، import، solver، آزمون و بسته‌بندی. این شماره نسخه به معنی پذیرش تمام الزامات یا آمادگی production نیست.

اصلاح سازگاری Windows PowerShell 5.1: bootstrap.ps1 با UTF-8 BOM ذخیره شد تا متن فارسی به‌اشتباه ANSI خوانده نشود. اجرای مستقیم PowerShell روی ویندوز در محیط Linux تست نشده است؛ بررسی بایت BOM و برابری متن انجام شد.

اصلاح نصب روی شبکه کند: timeout دریافت pip به ۱۸۰ ثانیه و retries به ۸ افزایش یافت؛ بررسی TLS و require-hashes حفظ شد. این تغییر رفع قطعی اختلال اینترنت یا proxy را تضمین نمی‌کند.

## ساخت هم‌زمان image مشترک
در برخی نسخه‌های Docker Desktop/BuildKit، سه build هم‌زمان برای یک tag با image already exists شکست می‌خورند. فقط api تنظیم build دارد؛ migrate و worker همان image را مصرف می‌کنند. bootstrap نخست `docker compose build api` و پس از موفقیت `docker compose up -d --no-build --wait api worker web` را اجرا می‌کند. فلگ `--no-build` در مرحله دوم مانع build هم‌زمان می‌شود. حذف image، volume یا داده برای این اصلاح لازم نیست.
