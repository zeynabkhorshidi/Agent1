"""Bounded CVRP with time windows over an explicitly synthetic matrix."""
import math, time
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

def distance(a,b):
    lat1,lat2=map(math.radians,[a['lat'],b['lat']]); dlat=lat2-lat1; dlon=math.radians(b['lon']-a['lon'])
    return round(6371000*2*math.asin(min(1,math.sqrt(math.sin(dlat/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2))))
def plan(stores,vehicles,depot,demands=None):
    if not stores or not vehicles: return {'status':'infeasible','reason':'مشتری یا خودروی فعال موجود نیست','routes':[],'unserved':[s['id'] for s in stores]}
    points=[depot]+[s['data'] for s in stores]; n=len(points); matrix=[[distance(a,b) for b in points] for a in points]
    manager=pywrapcp.RoutingIndexManager(n,len(vehicles),0); routing=pywrapcp.RoutingModel(manager)
    transit=routing.RegisterTransitCallback(lambda a,b: matrix[manager.IndexToNode(a)][manager.IndexToNode(b)])
    routing.SetArcCostEvaluatorOfAllVehicles(transit)
    demands=demands or {s['id']:12 for s in stores}
    cap=routing.RegisterUnaryTransitCallback(lambda a:0 if manager.IndexToNode(a)==0 else demands[stores[manager.IndexToNode(a)-1]['id']])
    routing.AddDimensionWithVehicleCapacity(cap,0,[v['data']['capacity_units'] for v in vehicles],True,'Capacity')
    tim=routing.RegisterTransitCallback(lambda a,b: round(matrix[manager.IndexToNode(a)][manager.IndexToNode(b)]/400)+(5 if manager.IndexToNode(a)>0 else 0))
    routing.AddDimension(tim,600,1080,False,'Time'); td=routing.GetDimensionOrDie('Time')
    for i,s in enumerate(stores,1):
        td.CumulVar(manager.NodeToIndex(i)).SetRange(*s['data'].get('window',[480,1080])); routing.AddDisjunction([manager.NodeToIndex(i)],1000000)
    for v,veh in enumerate(vehicles):
        td.CumulVar(routing.Start(v)).SetRange(*veh['data'].get('shift',[480,1080])); td.CumulVar(routing.End(v)).SetRange(*veh['data'].get('shift',[480,1080]))
    params=pywrapcp.DefaultRoutingSearchParameters(); params.first_solution_strategy=routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC; params.time_limit.seconds=2
    sol=routing.SolveWithParameters(params)
    if not sol:return {'status':'infeasible','routes':[],'unserved':[s['id'] for s in stores]}
    routes=[]; served=set()
    for v,veh in enumerate(vehicles):
        idx=routing.Start(v); stops=[]; meters=0
        while not routing.IsEnd(idx):
            node=manager.IndexToNode(idx)
            if node:
                s=stores[node-1]; served.add(s['id']); stops.append({'store_id':s['id'],'name':s['data']['name'],'arrival_minute':sol.Value(td.CumulVar(idx)),'load_units':demands[s['id']],'lat':s['data']['lat'],'lon':s['data']['lon']})
            nxt=sol.Value(routing.NextVar(idx)); meters+=matrix[node][manager.IndexToNode(nxt)]; idx=nxt
        if stops: routes.append({'vehicle_id':veh['id'],'stops':stops,'distance_m':meters,'capacity_units':veh['data']['capacity_units']})
    return {'status':'planned','routes':routes,'unserved':[s['id'] for s in stores if s['id'] not in served],'distance_m':sum(r['distance_m'] for r in routes),'provider':'synthetic-geodesic','traffic_mode':'none','warning':'خط مستقیم آزمایشی؛ مسیر خیابانی و ETA واقعی نیست','matrix_observed_at':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}

def coalition(baseline,group,handling=0,ai=0):
    saving=baseline-group-handling-ai
    return {'accepted':saving>0,'saving_rial':max(0,saving),'distributor_share_rial':max(0,saving)-max(0,saving)//2,'customer_share_rial':max(0,saving)//2,'policy_version':'equal-pool-v1','reason':'صرفه مثبت نسبت به مبنای واردشده' if saving>0 else 'صرفه اقتصادی مثبت وجود ندارد','baseline_source':'caller-supplied-demo-assumption'}
