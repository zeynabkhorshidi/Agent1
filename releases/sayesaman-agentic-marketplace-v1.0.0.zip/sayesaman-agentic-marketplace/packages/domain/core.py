import hashlib, json, secrets, re
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from sqlalchemy import select, update
from packages.domain.models import *

class DomainError(Exception):
    def __init__(self, code, message, status=409): self.code,self.message,self.status=code,message,status

def fail(code, message, status=409): raise DomainError(code,message,status)
def digest(v): return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def normalize(text):
    table=str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩يك','01234567890123456789یک')
    return re.sub(r'\s+',' ',text.translate(table).replace('\u200c',' ')).strip()
def money(value, unit='rial'):
    if unit not in ('rial','toman'): fail('CURRENCY','واحد پول مشخص نیست',422)
    d=Decimal(str(value))*(10 if unit=='toman' else 1)
    if not d.is_finite() or d<0 or d>10**15: fail('MONEY','مبلغ خارج از محدوده است',422)
    return int(d.quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def password_hash(p, salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.pbkdf2_hmac('sha256',p.encode(),salt.encode(),310000).hex()
def password_check(p,h): return secrets.compare_digest(password_hash(p,h.split(':')[0]),h)
def scope(u,r):
    if r.tenant!=u.tenant or r.branch!=u.branch or (u.role=='customer' and getattr(r,'store_id',None)!=u.store_id): fail('FORBIDDEN','دسترسی به این پرونده مجاز نیست',403)
def permit(u,*roles):
    if u.role not in roles: fail('FORBIDDEN','نقش شما اجازه این عملیات را ندارد',403)
def writable(db,u):
    if os.getenv('APP_MODE','demo')!='demo': fail('MODE_DISABLED','نوشتن خارج از دفتر دموی جداگانه فعال نیست',403)
    setting=db.get(Setting,'control')
    if setting and setting.value.get('kill_switch'): fail('KILL_SWITCH','عملیات نوشتن متوقف شده است',423)
    permit(u,'admin','sales','customer')
def event(db,u,typ,r,payload=None):
    db.add(Event(aggregate_id=r.id,actor=u.id,store_id=r.store_id,event_type=typ,tenant=u.tenant,branch=u.branch,payload=payload or {'status':r.status,'version':r.version}))
def record(db,u,kind,data,status='draft',store=None):
    r=Record(id=uid(),kind=kind,status=status,data=data,store_id=store,tenant=u.tenant,branch=u.branch); db.add(r); db.flush(); return r

def validate_intent(db,u,r):
    scope(u,r); writable(db,u)
    if r.kind!='intent' or r.status!='draft': fail('STATE','وضعیت درخواست برای اعتبارسنجی مناسب نیست')
    lines=r.data.get('lines',[])
    if not lines: fail('AMBIGUOUS_SKU','کالا و بسته‌بندی را از فهرست انتخاب کنید',422)
    for line in lines:
        p=db.get(Product,line['sku'])
        if not p or p.tenant!=u.tenant: fail('SKU','کالا یافت نشد',422)
    r.status='validated'; r.version+=1; event(db,u,'IntentValidated',r)

def issue_quote(db,u,intent):
    scope(u,intent); writable(db,u)
    if intent.status!='validated': fail('STATE','درخواست باید اعتبارسنجی شود')
    items=[]
    for l in intent.data['lines']:
        p=db.get(Product,l['sku']); q=l['quantity']*(p.pack if l['unit']=='carton' else 1)
        items.append({'sku':p.id,'code':p.code,'name':p.name,'quantity':q,'requested_quantity':l['quantity'],'requested_unit':l['unit'],'pack':p.pack,'unit_price_rial':p.price,'price_version':p.version,'total_rial':q*p.price})
    total=sum(x['total_rial'] for x in items)
    if total>intent.data['budget_rial']: fail('BUDGET','مبلغ از بودجه مجاز بیشتر است')
    data={'intent_id':intent.id,'items':items,'total_rial':total,'currency':'IRR','discount_rial':0,'tax_policy':'demo-no-tax','expires':(datetime.now(timezone.utc)+timedelta(minutes=15)).isoformat(),'delivery_day':intent.data['delivery_day'],'stock_observed_at':now(),'conditional':True,'provider':'deterministic-demo','erp_status':'not_sent'}
    data['terms_hash']=digest(data)
    p=record(db,u,'proposal',data,'awaiting_approval',intent.store_id)
    intent.status='awaiting_approval'; intent.version+=1
    event(db,u,'ProposalIssued',p,{'total_rial':total,'terms_hash':data['terms_hash']})
    a=record(db,u,'approval',{'proposal_id':p.id,'terms_hash':data['terms_hash'],'proposal_version':p.version},'pending',p.store_id)
    event(db,u,'ApprovalRequested',a)
    return p

def accept(db,u,pid,version,terms_hash,key):
    writable(db,u)
    if len(key)<8: fail('IDEMPOTENCY','کلید تکرارپذیری معتبر لازم است',422)
    fp=digest([u.id,pid,version,terms_hash]); ik=u.id+':'+key
    # Serialize operations on the same proposal across workers.
    p=db.scalar(select(Record).where(Record.id==pid).with_for_update())
    if not p: fail('NOT_FOUND','پیشنهاد یافت نشد',404)
    scope(u,p)
    old=db.get(Idempotency,ik)
    if old:
        if old.fingerprint!=fp: fail('KEY_REUSE','کلید برای درخواست دیگری استفاده شده است')
        return old.response
    if p.kind!='proposal' or p.status!='awaiting_approval': fail('STATE','پیشنهاد قابل پذیرش نیست')
    if p.version!=version or p.data['terms_hash']!=terms_hash: fail('VERSION','نسخه یا شرایط پیشنهاد تغییر کرده است')
    if p.data['expires']<now(): fail('QUOTE_EXPIRED','اعتبار پیشنهاد تمام شده است')
    # Lock control/mandate before any side effect. Revocation shares the same row lock.
    mandate=db.scalar(select(Record).where(Record.kind=='mandate',Record.store_id==p.store_id).with_for_update())
    if not mandate or mandate.status!='active' or mandate.data['expires']<now() or p.data['total_rial']>mandate.data['max_order_rial']: fail('MANDATE','اختیار خرید معتبر یا کافی نیست',403)
    approved=db.scalars(select(Record).where(Record.kind=='approval',Record.store_id==p.store_id)).all()
    a=next((x for x in approved if x.data['proposal_id']==p.id),None)
    if not a or a.status!='approved' or a.data['terms_hash']!=terms_hash: fail('APPROVAL','ابتدا نسخه فعلی پیشنهاد را تأیید کنید',403)
    allocations=[]
    for item in p.data['items']:
        product=db.get(Product,item['sku'])
        if product.version!=item['price_version'] or product.price!=item['unit_price_rial']: fail('PRICE_CHANGED','قیمت تغییر کرده؛ پیشنهاد جدید لازم است')
        remaining=item['quantity']
        batches=db.scalars(select(Stock).where(Stock.sku==product.id,Stock.quarantine==False,Stock.expiry>=(datetime.now(timezone.utc)+timedelta(days=7)).date().isoformat()).order_by(Stock.expiry,Stock.id).with_for_update()).all()
        for b in batches:
            take=min(remaining,b.on_hand-b.reserved)
            if take<=0: continue
            result=db.execute(update(Stock).where(Stock.id==b.id,Stock.on_hand-Stock.reserved>=take).values(reserved=Stock.reserved+take,version=Stock.version+1).execution_options(synchronize_session=False))
            if result.rowcount!=1: fail('STOCK_CONFLICT','موجودی هم‌زمان تغییر کرد؛ دوباره بررسی کنید')
            allocations.append({'batch_id':b.id,'quantity':take}); remaining-=take
            if remaining==0: break
        if remaining: fail('INSUFFICIENT_STOCK','موجودی قابل‌فروش کافی نیست')
    order=record(db,u,'order',{**p.data,'proposal_id':p.id,'allocations':allocations,'payment_state':'unpaid','fulfillment_state':'reserved','reservation_expires':(datetime.now(timezone.utc)+timedelta(minutes=30)).isoformat()},'confirmed',p.store_id)
    p.status='accepted'; p.version+=1
    intent=db.get(Record,p.data['intent_id']); intent.status='confirmed'; intent.version+=1
    record(db,u,'outbox',{'order_id':order.id,'destination':'demo-ledger','attempts':0},'pending',p.store_id)
    event(db,u,'StockReserved',order); event(db,u,'OrderConfirmed',order)
    response={'id':order.id,'status':order.status,'payment_state':'unpaid'}
    db.add(Idempotency(key=ik,fingerprint=fp,response=response)); return response

def release(db,u,order,reason='expired'):
    if order.status!='confirmed': return
    for a in order.data['allocations']:
        db.execute(update(Stock).where(Stock.id==a['batch_id'],Stock.reserved>=a['quantity']).values(reserved=Stock.reserved-a['quantity'],version=Stock.version+1))
    order.status=reason; order.version+=1; event(db,u,'StockReleased',order)

def fulfill(db,u,r,target):
    permit(u,'admin','warehouse'); scope(u,r)
    if target=='dispatched' and r.status=='confirmed':
        if r.data['reservation_expires']<now(): fail('RESERVATION_EXPIRED','رزرو منقضی شده است')
        for a in r.data['allocations']:
            res=db.execute(update(Stock).where(Stock.id==a['batch_id'],Stock.reserved>=a['quantity'],Stock.on_hand>=a['quantity']).values(on_hand=Stock.on_hand-a['quantity'],reserved=Stock.reserved-a['quantity'],version=Stock.version+1))
            if res.rowcount!=1: fail('STOCK_CONFLICT','رزرو با دفتر انبار سازگار نیست')
    elif not(target=='delivered' and r.status=='dispatched'): fail('STATE','تغییر وضعیت مجاز نیست')
    r.status=target; r.version+=1; r.data={**r.data,'fulfillment_state':target}; event(db,u,'DeliveryRecorded',r)
