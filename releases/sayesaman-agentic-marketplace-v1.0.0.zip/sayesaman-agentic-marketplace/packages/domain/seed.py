import argparse, getpass, secrets
from sqlalchemy import select
from packages.domain.core import *
SAMPLES=[('100255','شربت پرتقال سن ایچ ۱۲ × ۷۸۰ گرم',12,'6260100600041'),('100803','شربت پرتقال سن ایچ ۶ × ۷۸۰ گرم',6,'6260100600041'),('100337','نکتار پرتقال سن ایچ ۳۶ × ۲۰۰ میلی‌لیتر',36,'6260100684515'),('100308','آبمیوه سیب سن ایچ ۱۲ × ۱ لیتر',12,'6260100601147'),('101480','پاستیل اعداد شیبا ۲۴ × ۱۶۰ گرم',24,'6260101405621'),('101493','پاستیل میکس شیبا ۲۴ × ۱۶۰ گرم',24,'6260101405676'),('101810','پاستیل تمرهندی شیبا ۳۶ × ۹۰ گرم',36,'6260101402613'),('100433','پاستیل تمبر هندی شیبا ۳۲ × ۹۰ گرم',32,'6260101402613')]
def seed(db):
    if db.get(Setting,'seed'): return
    db.add(Setting(key='seed',value={'version':1,'synthetic':True})); db.add(Setting(key='control',value={'kill_switch':False,'name':'سایه‌سمن | بازار عامل‌های هوشمند'}))
    for i in range(30):
        code,name,pack,barcode=SAMPLES[i] if i<8 else (f'SYN{i:03}',f'نوشیدنی آزمایشی شماره {i-7}',12,f'DEMO{i:09}')
        pid=f'demo-sku-{i+1:02}'
        db.add(Product(id=pid,code='DEMO-'+code,name=name,pack=pack,barcode=barcode,price=120000+i*7000,cost=85000+i*4500,provenance={'source':'provided-document-unverified' if i<8 else 'synthetic-fixture','source_code':code,'synthetic_operational':True,'verified':False,'raw_weight_conflict':i in (0,1),'parser_version':'1'}))
        for w in range(2): db.add(Stock(id=f'{pid}-w{w}',sku=pid,warehouse=f'demo-warehouse-{w+1}',batch=f'DEMO-B{i}-{w}',expiry='2028-06-01',on_hand=300+w*100,reserved=0))
    for i in range(20):
        db.add(Record(id=f'demo-store-{i+1:02}',kind='store',store_id=f'demo-store-{i+1:02}',status='active',data={'name':f'فروشگاه آزمایشی {i+1:02}','lat':35.68+(i//5)*.035,'lon':51.32+(i%5)*.035,'synthetic':True,'window':[480,1080]}))
        db.add(Record(id=f'demo-mandate-{i+1:02}',kind='mandate',store_id=f'demo-store-{i+1:02}',status='active',data={'max_order_rial':100000000,'expires':'2028-12-31T00:00:00+00:00','authority':'execute-after-approval','substitution':False}))
    for i in range(2): db.add(Record(id=f'demo-warehouse-{i+1}',kind='warehouse',status='active',data={'name':f'انبار آزمایشی {i+1}','lat':35.70+i*.06,'lon':51.35+i*.06,'synthetic':True}))
    for i in range(3): db.add(Record(id=f'demo-vehicle-{i+1}',kind='vehicle',status='active',data={'name':f'خودرو آزمایشی {i+1}','capacity_units':500,'shift':[480,1080],'synthetic':True}))
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--user',choices=['admin','customer','sales','warehouse','viewer']); a=p.parse_args()
    with DB.begin() as db:
        seed(db)
        if a.user:
            password=getpass.getpass('رمز امن (حداقل ۱۲ نویسه): ')
            if len(password)<12: raise SystemExit('رمز کوتاه است')
            u=db.get(User,a.user)
            if u: u.password=password_hash(password)
            else: db.add(User(id=a.user,password=password_hash(password),role=a.user,store_id='demo-store-01' if a.user=='customer' else None))
