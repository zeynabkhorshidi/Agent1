"""Transactional ledger. All operational rows carry tenant/branch and UTC timestamps."""
import os, uuid
from datetime import datetime, timezone
from sqlalchemy import create_engine, String, Integer, BigInteger, JSON, Text, UniqueConstraint, CheckConstraint
from sqlalchemy.orm import DeclarativeBase, mapped_column, Mapped, sessionmaker

def now(): return datetime.now(timezone.utc).isoformat()
def uid(): return str(uuid.uuid4())
class Base(DeclarativeBase): pass
class Scope:
    tenant: Mapped[str] = mapped_column(String, default='demo')
    branch: Mapped[str] = mapped_column(String, default='tehran')
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[str] = mapped_column(String, default=now)
class User(Scope, Base):
    __tablename__='users'
    id: Mapped[str] = mapped_column(String, primary_key=True)
    password: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String)
    store_id: Mapped[str | None] = mapped_column(String, nullable=True)
class Session(Base):
    __tablename__='sessions'
    id: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(String)
    expires: Mapped[str] = mapped_column(String)
class Product(Scope, Base):
    __tablename__='products'
    id: Mapped[str] = mapped_column(String, primary_key=True)
    code: Mapped[str] = mapped_column(String, unique=True)
    name: Mapped[str] = mapped_column(String)
    barcode: Mapped[str] = mapped_column(String)
    pack: Mapped[int] = mapped_column(Integer)
    price: Mapped[int] = mapped_column(BigInteger)
    cost: Mapped[int] = mapped_column(BigInteger)
    provenance: Mapped[dict] = mapped_column(JSON)
    __table_args__=(CheckConstraint('pack > 0 AND price >= 0 AND cost >= 0'),)
class Stock(Scope, Base):
    __tablename__='stock'
    id: Mapped[str] = mapped_column(String, primary_key=True)
    sku: Mapped[str] = mapped_column(String)
    warehouse: Mapped[str] = mapped_column(String)
    batch: Mapped[str] = mapped_column(String)
    expiry: Mapped[str] = mapped_column(String)
    on_hand: Mapped[int] = mapped_column(Integer)
    reserved: Mapped[int] = mapped_column(Integer, default=0)
    quarantine: Mapped[bool] = mapped_column(default=False)
    __table_args__=(CheckConstraint('on_hand >= 0 AND reserved >= 0 AND reserved <= on_hand'),)
class Record(Scope, Base):
    __tablename__='records'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    kind: Mapped[str] = mapped_column(String, index=True)
    store_id: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String)
    data: Mapped[dict] = mapped_column(JSON, default=dict)
class Event(Scope, Base):
    __tablename__='events'
    seq: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    id: Mapped[str] = mapped_column(String, default=uid, unique=True)
    aggregate_id: Mapped[str] = mapped_column(String)
    actor: Mapped[str] = mapped_column(String)
    store_id: Mapped[str | None] = mapped_column(String, nullable=True)
    event_type: Mapped[str] = mapped_column(String)
    payload: Mapped[dict] = mapped_column(JSON)
class Idempotency(Base):
    __tablename__='idempotency'
    key: Mapped[str] = mapped_column(String, primary_key=True)
    fingerprint: Mapped[str] = mapped_column(String)
    response: Mapped[dict] = mapped_column(JSON)
class Setting(Base):
    __tablename__='settings'
    key: Mapped[str] = mapped_column(String, primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)
URL=os.getenv('DATABASE_URL','sqlite:///./demo.db')
engine=create_engine(URL, connect_args={'check_same_thread':False,'timeout':30} if URL.startswith('sqlite') else {}, pool_pre_ping=True)
DB=sessionmaker(engine, expire_on_commit=False)
