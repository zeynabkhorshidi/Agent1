"""Validated, content-addressed CSV/XLSX import; no remote URL fetches."""
import csv, io, hashlib
from openpyxl import load_workbook
from packages.domain.core import *

def preview(content,filename):
    if len(content)>2_000_000: fail('FILE_SIZE','حداکثر اندازه فایل دو مگابایت است',413)
    if filename.endswith('.csv'):
        try: rows=list(csv.DictReader(io.StringIO(content.decode('utf-8-sig'))))
        except (UnicodeError,csv.Error): fail('FILE_FORMAT','فایل CSV معتبر نیست',422)
    elif filename.endswith('.xlsx'):
        # Limit decompressed content to prevent zip bombs.
        import zipfile
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as z:
                if sum(x.file_size for x in z.infolist())>10_000_000: fail('FILE_SIZE','حجم بازشده فایل بیش از حد است',413)
            sheet=load_workbook(io.BytesIO(content),read_only=True,data_only=False).active
            it=sheet.iter_rows(values_only=True); headers=next(it); rows=[dict(zip(headers,row)) for row in it]
        except DomainError: raise
        except Exception: fail('FILE_FORMAT','فایل XLSX معتبر نیست',422)
    else: fail('FILE_FORMAT','فقط CSV و XLSX پشتیبانی می‌شود',422)
    if len(rows)>1000: fail('ROW_LIMIT','حداکثر هزار ردیف در هر واردسازی',422)
    valid=[]; errors=[]; seen=set()
    for index,row in enumerate(rows,2):
        try:
            code=str(row.get('code') or '').strip(); name=str(row.get('name') or '').strip(); barcode=str(row.get('barcode') or '')
            if not code or not name or len(code)>80 or len(name)>250 or any(str(v).lstrip().startswith(('=','+','-','@')) for v in row.values() if v is not None): raise ValueError('رکورد ناقص یا فرمول ناامن')
            if code in seen: raise ValueError('کد تکراری در فایل')
            pack=int(normalize(str(row['pack']))); price=int(normalize(str(row['price_rial']))); cost=int(normalize(str(row['cost_rial'])))
            if pack<=0 or price<0 or cost<0 or price>10**12 or cost>10**12: raise ValueError('مقدار خارج از محدوده')
            seen.add(code); valid.append({'code':code,'name':name,'barcode':barcode,'pack':pack,'price':price,'cost':cost,'row':index})
        except (ValueError,KeyError,TypeError) as e: errors.append({'row':index,'message':str(e) if not isinstance(e,KeyError) else 'ستون الزامی وجود ندارد'})
    return {'hash':hashlib.sha256(content).hexdigest(),'filename':filename,'rows':valid,'errors':errors,'row_count':len(rows),'valid_count':len(valid),'parser_version':'csv-xlsx-v1','source':'user-file-unverified','observed_at':now()}

def commit_import(db,u,job):
    if job.status=='committed': return job
    if job.status!='preview' or job.data['errors']: fail('IMPORT_ERRORS','خطاهای فایل را قبل از ثبت برطرف کنید',422)
    for row in job.data['rows']:
        existing=db.scalar(select(Product).where(Product.code==row['code']))
        if existing: fail('IMPORT_CONFLICT','کد موجود است؛ اصلاح قیمت یا بسته‌بندی نیازمند بررسی جداگانه است')
    for row in job.data['rows']:
        db.add(Product(id=uid(),code=row['code'],name=row['name'],barcode=row['barcode'],pack=row['pack'],price=row['price'],cost=row['cost'],provenance={'source':job.data['source'],'hash':job.data['hash'],'verified':False,'synthetic_operational':True,'import_id':job.id}))
    job.status='committed'; job.version+=1; event(db,u,'CatalogImported',job,{'count':len(job.data['rows']),'hash':job.data['hash']}); return job
