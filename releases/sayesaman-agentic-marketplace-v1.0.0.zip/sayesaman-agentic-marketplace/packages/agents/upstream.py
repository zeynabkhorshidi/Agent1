"""Use the upstream text protocol, never its float money or Payment semantics."""
import sys, importlib.util
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'vendor/multi-agent-marketplace/packages/magentic-marketplace/src'))
_path=Path(__file__).resolve().parents[2]/'vendor/multi-agent-marketplace/packages/magentic-marketplace/src/magentic_marketplace/marketplace/actions/messaging.py'
_spec=importlib.util.spec_from_file_location('sayesaman_upstream_messaging',_path)
_module=importlib.util.module_from_spec(_spec)
sys.modules[_spec.name]=_module
_spec.loader.exec_module(_module)
TextMessage, MessageAdapter=_module.TextMessage, _module.MessageAdapter

def evidence_message(payload):
    import json
    msg=TextMessage(content=json.dumps(payload,ensure_ascii=False))
    return MessageAdapter.validate_json(MessageAdapter.dump_json(msg)).model_dump()
