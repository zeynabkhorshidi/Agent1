from sqlalchemy import select, update
from packages.domain.core import *
from packages.agents.upstream import evidence_message

def process_one():
    with DB.begin() as db:
        job=db.scalar(select(Record).where(Record.kind=='run',Record.status=='queued').order_by(Record.created_at).limit(1).with_for_update(skip_locked=True))
        if not job: return False
        # Run inside one transaction: a crash rolls back both claim and proposal.
        if db.execute(update(Record).where(Record.id==job.id,Record.status=='queued').values(status='running').execution_options(synchronize_session=False)).rowcount!=1: return True
        u=db.get(User,job.data['actor']); intent=db.scalar(select(Record).where(Record.id==job.data['intent_id']).with_for_update())
        try:
            with db.begin_nested():
                usage={'provider':'deterministic-demo','tokens':0,'cost_rial':0}
                model_summary=None
                if job.data.get('provider','demo')!='demo':
                    from packages.integrations.llm import LLMGateway
                    suggestion,usage=LLMGateway().suggest(intent.data['lines'])
                    model_summary=suggestion['summary_fa']
                    if suggestion['action']!='request_quote': fail('NEEDS_REVIEW','مدل درخواست بررسی انسانی دارد',422)
                proposal=issue_quote(db,u,intent)
                steps=[{'tool':'resolve_sku','status':'ok','evidence_ids':[x['sku'] for x in proposal.data['items']]},{'tool':'get_price_quote','status':'ok','evidence_ids':[proposal.id]},{'tool':'request_approval','status':'ok','evidence_ids':[proposal.id]}]
                job.data={**job.data,'proposal_id':proposal.id,'steps':steps,'message':evidence_message({'proposal_id':proposal.id,'summary':'قیمت قطعی دمو محاسبه شد؛ تأیید نسخه لازم است.'}),'model_summary':model_summary,'model_usage':usage,'max_steps':6}
            job.status='completed'
        except DomainError as e:
            job.status='failed'; job.data={**job.data,'error_code':e.code,'error':e.message}
        event(db,u,'AgentRunCompleted',job)
    return True
