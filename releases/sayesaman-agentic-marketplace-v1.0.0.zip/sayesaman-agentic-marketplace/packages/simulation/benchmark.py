"""Synthetic distance comparison. C_demo has no live model; C_live stays unrun."""
import random,json,time,csv,hashlib
from pathlib import Path
from packages.domain.routing import plan,distance

def run():
 rows=[]
 for seed in [17,31,47]:
  rng=random.Random(seed); depot={'lat':35.70,'lon':51.35}
  stores=[{'id':f's{i}','data':{'name':f'آزمایشی {i}','lat':35.68+rng.random()*.12,'lon':51.3+rng.random()*.15,'window':[480,1080]}} for i in range(20)]
  dataset_hash=hashlib.sha256(json.dumps(stores,sort_keys=True).encode()).hexdigest()
  for disruption in [0,1,2]:
   vehicles=[{'id':f'v{i}','data':{'capacity_units':120,'shift':[480,1080]}} for i in range(3-disruption)]
   for method in ['A_fixed_feasible','B_optimizer','C_demo_optimizer']:
    start=time.perf_counter()
    if method=='A_fixed_feasible':
     # Fixed first-fit routes, all stops within a 10h window in this bounded fixture.
     served=stores[:len(vehicles)*10]; meters=0
     for i in range(0,len(served),10):
      points=[depot]+[x['data'] for x in served[i:i+10]]+[depot];meters+=sum(distance(a,b) for a,b in zip(points,points[1:]))
     unserved=len(stores)-len(served)
    else:
     result=plan(stores,vehicles,depot);meters=result.get('distance_m',0);unserved=len(result['unserved'])
    rows.append({'method':method,'seed':seed,'vehicles_removed':disruption,'dataset_hash':dataset_hash,'distance_m':meters,'served_orders':20-unserved,'unserved_orders':unserved,'fill_rate_orders':(20-unserved)/20,'elapsed_ms':round((time.perf_counter()-start)*1000,3),'llm_tokens':0,'llm_cost_rial':0,'money_roi':None,'synthetic':True})
 output={'rows':rows,'C_live':{'status':'unrun','reason':'No approved provider/model credentials or tariff supplied'},'conclusion_fa':'این آزمایش فقط فاصله هندسی مصنوعی را مقایسه می‌کند. C دمو همان بهینه‌ساز B است؛ ارزش افزوده AI زنده اثبات نشده است.','config_hash':hashlib.sha256(b'20-stores-12-units-120-capacity-v1').hexdigest(),'assumptions':['geodesic meters, not road geometry','400 meters/minute synthetic travel','5 minute service time','all demand windows 480..1080','no real prices or ROI']}
 Path('reports/benchmark.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
 with open('reports/benchmark.csv','w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
 return output
if __name__=='__main__':run()
