# Third-party notices
Microsoft Magentic Marketplace: MIT; full source and license under vendor/.
Vazirmatn: SIL Open Font License 1.1, see docs/VAZIRMATN-LICENSE.txt; fonts bundled by @fontsource.
React/React DOM/Vite/TypeScript/lucide-react: MIT; exact versions in package-lock.json.
FastAPI: MIT; SQLAlchemy: MIT; Pydantic: MIT; Uvicorn: BSD-3-Clause; Alembic: MIT; psycopg: LGPL-3.0; OR-Tools: Apache-2.0; openpyxl: MIT; httpx: BSD-3-Clause. Exact dependencies, hashes and transitive versions in uv.lock/requirements.lock and package-lock.json.
No Microsoft or company logo, external tiles, commercial catalog images, model weights or private audio are bundled. Company name is descriptive; square س is a typographic UI mark, not the official logo.
Container base images retain their respective upstream licensing and are downloaded separately.
