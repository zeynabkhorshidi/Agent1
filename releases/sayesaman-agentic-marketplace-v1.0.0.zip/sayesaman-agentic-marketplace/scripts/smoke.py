import os,httpx
base=os.getenv('SMOKE_URL','http://127.0.0.1:8000')
r=httpx.get(base+'/api/v1/health/ready');r.raise_for_status();assert r.json()['status']=='ready'
r=httpx.get(base+'/');r.raise_for_status();assert 'lang="fa"' in r.text
print('readiness and Persian frontend: PASS')
