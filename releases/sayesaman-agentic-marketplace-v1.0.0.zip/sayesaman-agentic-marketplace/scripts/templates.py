from pathlib import Path
import csv,json
from openpyxl import Workbook
from packages.domain.seed import SAMPLES
p=Path('data/demo');p.mkdir(parents=True,exist_ok=True)
headers=['code','name','barcode','pack','price_rial','cost_rial']
rows=[['IMPORT-DEMO-1','کالای وارداتی آزمایشی','DEMO0001',12,150000,100000]]
with (p/'catalog-template.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(headers);w.writerows(rows)
w=Workbook();s=w.active;s.append(headers)
for r in rows:s.append(r)
w.save(p/'catalog-template.xlsx')
Path('data/catalog_snapshots/document-samples.json').write_text(json.dumps({'source':'owner-provided-document','verified_against_site':False,'records':[{'code':c,'name':n,'pack':p,'barcode':b} for c,n,p,b in SAMPLES]},ensure_ascii=False,indent=2))
