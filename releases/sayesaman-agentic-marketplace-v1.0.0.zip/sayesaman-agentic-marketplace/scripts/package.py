"""Build a source archive, scan high-confidence secret patterns, hash every entry."""
from pathlib import Path
import zipfile,hashlib,json,re,sys
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'artifacts';OUT.mkdir(exist_ok=True)
archive=OUT/'sayesaman-agentic-marketplace-v1.0.0.zip'
excluded={'.git','.venv','node_modules','__pycache__','.pytest_cache','.ruff_cache','artifacts','.next','.cache','playwright-report','test-results'}
patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b',rb'\bAKIA[0-9A-Z]{16}\b',rb'\bsk-proj-[A-Za-z0-9_-]{35,}\b']
files=[];violations=[]
for p in sorted(ROOT.rglob('*')):
 rel=p.relative_to(ROOT)
 if any(x in excluded for x in rel.parts):continue
 if p.is_symlink():raise SystemExit('Symlink rejected: '+str(rel))
 if not p.is_file() or p.name in {'.env','MANIFEST.json','SECRET_SCAN.json'} or p.name.endswith(('.db','.db-wal','.db-shm','.pyc','.dump','.log','.zip')):continue
 content=p.read_bytes()
 if any(re.search(pattern,content) for pattern in patterns):violations.append(str(rel))
 files.append((p,str(rel),hashlib.sha256(content).hexdigest(),len(content)))
if violations:raise SystemExit('Potential credential patterns; review files: '+', '.join(violations))
manifest={'project':'sayesaman-agentic-marketplace','version':'1.0.0','files':[{'path':rel,'sha256':h,'bytes':size} for _,rel,h,size in files]}
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(ROOT/'SECRET_SCAN.json').write_text(json.dumps({'result':'passed','files_scanned':len(files),'method':'excluded runtime secrets and caches; high-confidence token/private-key patterns','limitations':'pattern scan is not a security audit; synthetic test credentials are public fixtures'},indent=2))
files.extend([(ROOT/'MANIFEST.json','MANIFEST.json','',0),(ROOT/'SECRET_SCAN.json','SECRET_SCAN.json','',0)])
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,rel,_,_ in files:
  name='sayesaman-agentic-marketplace/'+rel
  entry=zipfile.ZipInfo(name,date_time=(2026,11,3,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=(0o100755 if p.suffix=='.sh' else 0o100644)<<16
  z.writestr(entry,p.read_bytes())
hash=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(hash+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hash,'files':len(files)}))
