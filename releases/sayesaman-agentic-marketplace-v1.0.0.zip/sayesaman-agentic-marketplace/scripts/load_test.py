"""Only run on an isolated database explicitly named sayesaman_load."""
import os,time,statistics,json,platform
from concurrent.futures import ThreadPoolExecutor
from datetime import date,timedelta
from pathlib import Path
assert os.environ['DATABASE_URL'].endswith('/sayesaman_load'),'isolated load database required'
from fastapi.testclient import TestClient
from services.api.main import app
from packages.domain.core import *
from packages.domain.seed import seed
from packages.agents.runner import process_one
Base.metadata.create_all(engine)
with DB.begin() as db:
 seed(db)
 if not db.get(User,'load-admin'): db.add(User(id='load-admin',role='admin',password=password_hash('ephemeral-load-test-password')))
 for i in range(20,1000):
  sid=f'load-store-{i}'
  if not db.get(Record,sid): db.add(Record(id=sid,kind='store',status='active',store_id=sid,data={'name':f'مصنوعی {i}','lat':35.7,'lon':51.4,'window':[480,1080]}))
with TestClient(app) as c:
 d=c.post('/api/v1/auth/login',json={'username':'load-admin','password':'ephemeral-load-test-password'}).json();c.headers['X-CSRF-Token']=d['csrf_token']
 def request(i):
  start=time.perf_counter();r=c.get('/api/v1/catalog/products?q=سن');return (time.perf_counter()-start)*1000,r.status_code
 with ThreadPoolExecutor(20) as pool: results=list(pool.map(request,range(200)))
 for i in range(100):
  r=c.post('/api/v1/purchase-intents',json={'store_id':'demo-store-01','text':'نیاز مصنوعی بار','lines':[{'sku':'demo-sku-01','quantity':1,'unit':'each'}],'budget_rial':1000000,'delivery_day':str(date.today()+timedelta(days=1))});r.raise_for_status();rid=r.json()['id'];c.post(f'/api/v1/purchase-intents/{rid}/validate').raise_for_status();c.post('/api/v1/agent-runs',json={'intent_id':rid}).raise_for_status()
 start=time.perf_counter()
 with ThreadPoolExecutor(20) as pool:list(pool.map(lambda _:process_one(),range(100)))
 elapsed=time.perf_counter()-start
 with DB() as db:done=len(db.scalars(select(Record).where(Record.kind=='run',Record.status=='completed')).all())
 vals=sorted(x[0] for x in results)
 out={'synthetic':True,'database':'PostgreSQL isolated sayesaman_load','clients_stored':1000,'intent_count':100,'worker_concurrency':20,'runs_completed':done,'worker_elapsed_seconds':elapsed,'catalog_requests':200,'catalog_concurrency':20,'p50_ms':statistics.median(vals),'p95_ms':vals[int(len(vals)*.95)-1],'errors':sum(s!=200 for _,s in results),'cpu_count':os.cpu_count(),'memory_mb':int(Path('/proc/meminfo').read_text().split('MemTotal:')[1].split()[0])//1024,'platform':platform.platform(),'limits':'local TestClient HTTP stack, synthetic data, no external provider or solver in API latency target'}
 Path('reports/load.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False))
