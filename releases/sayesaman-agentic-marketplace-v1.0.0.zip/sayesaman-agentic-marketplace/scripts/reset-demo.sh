#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ "${1:-}" = '--delete-demo-data' ] || { echo 'برای حذف داده فقط دمو: reset-demo.sh --delete-demo-data'; exit 1; }
docker compose down -v
bash scripts/bootstrap.sh
