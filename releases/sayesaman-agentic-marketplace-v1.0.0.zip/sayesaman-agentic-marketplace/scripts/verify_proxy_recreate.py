"""Verify proxy recovery after API IP changes without restarting Nginx."""
import subprocess,json,time,uuid,urllib.request
from pathlib import Path
prefix='sayesaman-proxy-check-'+uuid.uuid4().hex[:8]
network=prefix+'-net';old=prefix+'-old';new=prefix+'-new';holder=prefix+'-holder';web=prefix+'-web'
config=Path('infra/nginx.conf').resolve()
def docker(*args):return subprocess.check_output(['docker',*args],stderr=subprocess.STDOUT).decode().strip()
def backend(name,label,ip=None):
 code='from http.server import BaseHTTPRequestHandler,HTTPServer; import json\nclass H(BaseHTTPRequestHandler):\n def do_GET(self):\n  self.send_response(200); self.end_headers(); self.wfile.write(json.dumps({"backend":'+repr(label)+',"path":self.path}).encode())\nHTTPServer(("0.0.0.0",8000),H).serve_forever()'
 return docker('run','-d','--name',name,'--network',network,'--network-alias','api',*(('--ip',ip) if ip else ()),'sayesaman-marketplace:1.0.0','python','-c',code)
def wait(label):
 for _ in range(30):
  try:
   data=json.loads(urllib.request.urlopen('http://127.0.0.1:18081/api/v1/health/ready?check=proxy',timeout=2).read())
   if data['backend']==label:
    assert data['path']=='/api/v1/health/ready?check=proxy';return
  except Exception:pass
  time.sleep(1)
 raise RuntimeError('Proxy did not reach '+label)
try:
 docker('network','create','--subnet','198.19.'+str(int(uuid.uuid4().hex[:2],16))+'.0/24',network);backend(old,'before')
 old_ip=json.loads(docker('inspect',old))[0]['NetworkSettings']['Networks'][network]['IPAddress']
 web_id=docker('run','-d','--name',web,'--network',network,'-p','127.0.0.1:18081:8080','-v',str(config)+':/etc/nginx/nginx.conf:ro','nginx:1.28.0-alpine')
 wait('before');docker('rm','-f',old)
 # Occupy the old IP so the replacement must use a different address.
 docker('run','-d','--name',holder,'--network',network,'--ip',old_ip,'sayesaman-marketplace:1.0.0','python','-c','import time;time.sleep(180)')
 backend(new,'after')
 new_ip=json.loads(docker('inspect',new))[0]['NetworkSettings']['Networks'][network]['IPAddress'];assert new_ip!=old_ip
 wait('after');assert docker('inspect','--format','{{.Id}}',web)==web_id
 result={'result':'passed','api_ip_changed':True,'nginx_restarted':False,'query_and_path_preserved':True}
 Path('reports/proxy-recreate.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
finally:
 for name in [old,new,holder,web]:subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run(['docker','network','rm',network],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
