#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ "$#" -eq 1 ] || { echo 'مسیر فایل backup را بدهید'; exit 1; }
umask 077
docker compose exec -T db pg_dump -U sayesaman -d sayesaman_demo -Fc > "$1"
[ -s "$1" ]
