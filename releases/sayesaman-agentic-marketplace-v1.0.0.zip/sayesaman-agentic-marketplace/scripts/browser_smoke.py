"""Run against a seeded demo with account credentials supplied outside source."""
import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
credentials=json.loads(Path(os.environ['BROWSER_CREDENTIALS_FILE']).read_text())
base=os.getenv('SMOKE_URL','http://127.0.0.1:8000')
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(base);page.get_by_label('نام کاربری').fill(credentials['username']);page.get_by_label('رمز عبور').fill(credentials['password']);page.get_by_role('button',name='ورود امن').click();page.get_by_role('heading',name='مرکز عملیات').wait_for()
 page.screenshot(path='reports/desktop-dashboard.png',full_page=True)
 page.get_by_role('link',name='درخواست خرید',exact=True).click();page.get_by_role('button',name='اعتبارسنجی و اجرای عامل').click();page.get_by_role('status').wait_for()
 page.get_by_role('link',name='میز معامله',exact=True).click();page.get_by_role('button',name='تأیید این نسخه و ثبت سفارش').first.wait_for(timeout=15000);page.get_by_role('button',name='تأیید این نسخه و ثبت سفارش').first.click();page.get_by_text('سفارش مستقل ثبت و موجودی رزرو شد؛ پرداخت انجام نشده است').wait_for()
 page.get_by_role('link',name='سفارش و تحویل',exact=True).click();page.get_by_role('button',name='ثبت خروج از انبار دمو').first.click();page.get_by_role('button',name='ثبت تحویل دمو').first.click()
 page.get_by_text('تحویل‌شده',exact=True).first.wait_for()
 page.get_by_role('link',name='کاتالوگ کالا',exact=True).click();page.get_by_label('جست‌وجوی کالا').fill('پرتقال');page.wait_for_timeout(600);assert page.locator('tbody tr').count()==3
 page.screenshot(path='reports/desktop-catalog.png',full_page=True)
 page.set_viewport_size({'width':390,'height':844});page.goto(base+'/#customer');page.get_by_role('heading',name='درخواست خرید').wait_for();page.locator('select').first.locator('option').first.wait_for(state='attached');page.screenshot(path='reports/mobile-intent.png',full_page=True)
 assert page.locator('html').get_attribute('dir')=='rtl'
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'mobile horizontal overflow'
 assert not errors,errors
 Path('reports/browser.json').write_text(json.dumps({'result':'passed','flow':'login → intent → worker → quote → approval → order → dispatch → delivered','desktop':[1440,1100],'mobile':[390,844],'uncaught_errors':errors},ensure_ascii=False,indent=2));b.close()
print('browser desktop/mobile Persian E2E: PASS')
