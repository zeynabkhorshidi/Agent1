"""Run against a seeded demo with account credentials supplied outside source."""
import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
credentials=json.loads(Path(os.environ['BROWSER_CREDENTIALS_FILE']).read_text())
base=os.getenv('SMOKE_URL','http://127.0.0.1:8000')
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(base);page.get_by_role('heading',name='ورود به سامانه').wait_for();page.evaluate('() => document.fonts.ready');page.screenshot(path='reports/login.png',full_page=True);page.get_by_label('نام کاربری').fill(credentials['username']);page.get_by_label('رمز عبور').fill(credentials['password']);page.get_by_role('button',name='ورود امن').click();page.get_by_role('heading',name='مرکز عملیات').wait_for()
 page.evaluate('() => document.fonts.ready')
 assert page.evaluate("() => getComputedStyle(document.body).fontFamily.includes('IRANSansX')")
 assert 'SAYESAMAN WORKSPACE' not in page.locator('body').inner_text()
 assert 'منبع:' not in page.locator('body').inner_text()
 cdp=page.context.new_cdp_session(page);cdp.send('DOM.enable');cdp.send('CSS.enable');root=cdp.send('DOM.getDocument');node=cdp.send('DOM.querySelector',{'nodeId':root['root']['nodeId'],'selector':'h1'});rendered=cdp.send('CSS.getPlatformFontsForNode',{'nodeId':node['nodeId']})['fonts']
 assert any(f['isCustomFont'] and 'iransans' in f['familyName'].lower() for f in rendered),rendered
 small_text=page.evaluate("""() => [...document.querySelectorAll('main *,header *,nav *')].filter(e=>e.getClientRects().length && [...e.childNodes].some(n=>n.nodeType===3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize)<13).map(e=>e.textContent.slice(0,60))""")
 assert not small_text,small_text
 page.screenshot(path='reports/desktop-dashboard.png',full_page=True)
 page.get_by_role('link',name='درخواست خرید',exact=True).click();page.get_by_role('button',name='اعتبارسنجی و اجرای عامل').click();page.get_by_role('status').wait_for()
 page.get_by_role('link',name='میز معامله',exact=True).click();page.get_by_role('button',name='تأیید این نسخه و ثبت سفارش').first.wait_for(timeout=15000);page.get_by_role('button',name='تأیید این نسخه و ثبت سفارش').first.click();page.get_by_text('سفارش مستقل ثبت و موجودی رزرو شد؛ پرداخت انجام نشده است').wait_for()
 page.get_by_role('link',name='سفارش و تحویل',exact=True).click();page.get_by_role('button',name='ثبت خروج از انبار دمو').first.click();page.get_by_role('button',name='ثبت تحویل دمو').first.click()
 page.get_by_text('تحویل‌شده',exact=True).first.wait_for()
 page.get_by_role('link',name='کاتالوگ کالا',exact=True).click();page.get_by_label('جست‌وجوی کالا').fill('پرتقال');page.wait_for_timeout(600);assert page.locator('tbody tr').count()==3
 page.screenshot(path='reports/desktop-catalog.png',full_page=True)
 page.set_viewport_size({'width':390,'height':844});page.goto(base+'/#customer');page.get_by_role('heading',name='درخواست خرید').wait_for();page.locator('select').first.locator('option').first.wait_for(state='attached');page.screenshot(path='reports/mobile-intent.png',full_page=True)
 assert page.locator('html').get_attribute('dir')=='rtl'
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'mobile horizontal overflow'
 assert not errors,errors
 Path('reports/browser.json').write_text(json.dumps({'result':'passed','flow':'login → intent → worker → quote → approval → order → dispatch → delivered','desktop':[1440,1100],'mobile':[390,844],'uncaught_errors':errors,'font':'IRANSansX (custom font confirmed by Chromium)','dashboard_text_min_px':13},ensure_ascii=False,indent=2));b.close()
print('browser desktop/mobile Persian E2E: PASS')
