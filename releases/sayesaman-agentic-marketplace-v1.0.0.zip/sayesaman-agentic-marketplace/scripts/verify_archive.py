from pathlib import Path
import zipfile,hashlib,json,sys
archive=Path(sys.argv[1]);dest=Path(sys.argv[2]);dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for info in z.infolist():
  p=Path(info.filename)
  assert not p.is_absolute() and '..' not in p.parts
 z.extractall(dest)
root=dest/'sayesaman-agentic-marketplace';manifest=json.loads((root/'MANIFEST.json').read_text())
for item in manifest['files']:
 p=root/item['path'];assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
assert (root/'vendor/multi-agent-marketplace/packages/magentic-marketplace/src/magentic_marketplace/marketplace/actions/messaging.py').is_file()
assert not list(root.rglob('node_modules')) and not list(root.rglob('.venv'))
print('ZIP extraction, manifest and non-empty upstream: PASS')
