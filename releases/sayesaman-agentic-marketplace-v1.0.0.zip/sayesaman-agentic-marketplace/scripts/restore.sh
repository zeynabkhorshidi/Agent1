#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ "$#" -eq 2 ] && [ "$2" = '--replace-demo' ] || { echo 'restore.sh FILE --replace-demo فقط برای دیتابیس دمو'; exit 1; }
docker compose stop api worker web
docker compose exec -T db pg_restore -U sayesaman -d sayesaman_demo --clean --if-exists < "$1"
docker compose up -d --wait api worker web
