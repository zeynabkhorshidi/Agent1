#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
.venv/bin/pytest --junitxml=reports/tests.xml
npm --prefix apps/web run build
