#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
uv sync --frozen
npm --prefix apps/web ci --ignore-scripts
npm --prefix apps/web run build
.venv/bin/alembic upgrade head
.venv/bin/python -m packages.domain.seed
.venv/bin/python -m services.worker.main &
worker_pid=$!
trap 'kill "$worker_pid" 2>/dev/null || true' EXIT INT TERM
.venv/bin/uvicorn services.api.main:app --host 127.0.0.1 --port 8000
