"""Local isolated compose verification. Never include generated .env in an archive."""
import os,secrets,subprocess,json,time,urllib.request
from pathlib import Path

def run(*args,**kwargs):return subprocess.run(['docker','compose',*args],check=True,**kwargs)
if not Path('.env').exists():
 fd=os.open('.env',os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
 with os.fdopen(fd,'w') as f:f.write(Path('.env.example').read_text()+'\nDB_PASSWORD='+secrets.token_hex(24)+'\n')
run('up','-d','--no-build','--wait','api','worker','web')
health=json.loads(urllib.request.urlopen('http://127.0.0.1:8080/api/v1/health/ready').read());assert health['status']=='ready'
# Backup and restore into a separate database, not over the running demo.
dump=subprocess.check_output(['docker','compose','exec','-T','db','pg_dump','-U','sayesaman','-d','sayesaman_demo','-Fc'])
run('exec','-T','db','createdb','-U','sayesaman','sayesaman_restore_test')
run('exec','-T','db','pg_restore','-U','sayesaman','-d','sayesaman_restore_test',input=dump)
count=subprocess.check_output(['docker','compose','exec','-T','db','psql','-U','sayesaman','-d','sayesaman_restore_test','-Atc','SELECT count(*) FROM products']).decode().strip();assert count=='30'
run('exec','-T','db','dropdb','-U','sayesaman','sayesaman_restore_test')
Path('reports/compose.json').write_text(json.dumps({'compose_start':'passed','postgres_migration':'passed','seeded_product_count':30,'ready':health,'backup_restore':'passed','restored_product_count':int(count),'backup_bytes':len(dump),'backup_file_retained':False,'real_integrations':'unrun'},ensure_ascii=False,indent=2))
print('compose readiness and isolated backup/restore: PASS')
