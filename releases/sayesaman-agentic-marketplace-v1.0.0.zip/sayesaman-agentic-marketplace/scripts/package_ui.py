"""Package only the frontend and its font notices for updating existing installs."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1];out=root.parent/'artifacts';out.mkdir(exist_ok=True)
archive=out/'sayesaman-ui-update.zip'
files=[p for p in sorted((root/'apps/web').rglob('*')) if p.is_file() and not any(x in {'node_modules','dist','.git'} for x in p.relative_to(root).parts)]
files += [root/'THIRD_PARTY_NOTICES.md',root/'docs/IRANSANSX.fa.md']
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:
  name=p.relative_to(root).as_posix();content=p.read_bytes();z.writestr(name,content);manifest.append({'path':name,'sha256':hashlib.sha256(content).hexdigest()})
 z.writestr('UI_UPDATE_MANIFEST.json',json.dumps(manifest,indent=2))
 z.writestr('UPDATE_UI.fa.md','''# به‌روزرسانی ظاهر
این ZIP فقط رابط وب و فونت‌های ارسالی مالک را دارد.
محتوا را داخل پوشه فعلی پروژه استخراج و فایل‌های هم‌نام را جایگزین کنید؛ پوشه apps داخل ZIP باید با apps پروژه ادغام شود.
در PowerShell همان پوشه اجرا کنید:

```powershell
docker compose build api
if ($LASTEXITCODE -eq 0) {
    docker compose up -d --no-build --wait api worker web
    docker compose restart web
}
```
سپس مرورگر را با Ctrl+F5 تازه کنید. این بسته فایل .env، دیتابیس و تنظیمات اتصال را تغییر نمی‌دهد.
''')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
archive.with_suffix('.zip.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'patch':str(archive),'bytes':archive.stat().st_size,'files':len(files),'integrity':'passed'}))
