"""Small proxy configuration update; no application credentials or data."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1];out=root.parent/'artifacts';out.mkdir(exist_ok=True)
archive=out/'sayesaman-proxy-update.zip';manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ['infra/nginx.conf','compose.yaml']:
  content=(root/name).read_bytes();z.writestr(name,content);manifest.append({'path':name,'sha256':hashlib.sha256(content).hexdigest()})
 z.writestr('PROXY_UPDATE_MANIFEST.json',json.dumps(manifest,indent=2))
 z.writestr('UPDATE_PROXY.fa.md','''# اصلاح اتصال Nginx به API
فایل‌های بسته را در پوشه فعلی پروژه استخراج و جایگزین کنید. سپس در PowerShell همان پوشه:

```powershell
docker compose up -d --no-deps --no-build --force-recreate --wait web
```
این دستور فقط سرویس web را بازسازی می‌کند؛ API باید پیش از آن سالم و در حال اجرا باشد.
پس از موفقیت، http://localhost:8080 را با Ctrl+F5 تازه کنید. اگر هنوز خطا وجود داشت، خروجی docker compose logs --tail=30 web api را بررسی کنید.
''')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
archive.with_suffix('.zip.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'integrity':'passed'}))
