# وضعیت ادامه کار
- مخزن مبنا و MIT/TRANSPARENCY ممیزی، SHA pin و کل vendor همراه پروژه شد.
- هسته DB/مهاجرت/seed/API/احراز هویت/worker/پیشنهاد/تأیید/رزرو/سفارش/تحویل پیاده شد.
- SPA ده صفحه فارسی به API واقعی وصل؛ font محلی و جدول جایگزین نقشه.
- import CSV/XLSX preview و commit محدود، OR-Tools synthetic routing، economics calculator و benchmark synthetic.
- تست‌ها و build واقعی در reports؛ برای وضعیت نهایی به فایل‌های خروجی رجوع کنید.
- اتصال‌های واقعی و قابلیت‌های ناتمام در BLOCKERS.fa.md. هیچ production deployment، push به GitHub، ارسال به مشتری یا ثبت در ERP انجام نشده است.

ادامه از همین سورس؛ stack را بدون ADR عوض نکنید. محیط cloud ایزوله است؛ از checkout موجود استفاده کنید و بدون درخواست صریح worktree نسازید. پس از بازیابی فرآیند API/worker باید دوباره شروع شود.

اصلاح سازگاری Windows PowerShell 5.1: bootstrap.ps1 با UTF-8 BOM ذخیره شد تا متن فارسی به‌اشتباه ANSI خوانده نشود. اجرای مستقیم PowerShell روی ویندوز در محیط Linux تست نشده است؛ بررسی بایت BOM و برابری متن انجام شد.

اصلاح نصب روی شبکه کند: timeout دریافت pip به ۱۸۰ ثانیه و retries به ۸ افزایش یافت؛ بررسی TLS و require-hashes حفظ شد. این تغییر رفع قطعی اختلال اینترنت یا proxy را تضمین نمی‌کند.

## ساخت هم‌زمان image مشترک
در برخی نسخه‌های Docker Desktop/BuildKit، سه build هم‌زمان برای یک tag با image already exists شکست می‌خورند. فقط api تنظیم build دارد؛ migrate و worker همان image را مصرف می‌کنند. bootstrap نخست `docker compose build api` و پس از موفقیت `docker compose up -d --no-build --wait api worker web` را اجرا می‌کند. فلگ `--no-build` در مرحله دوم مانع build هم‌زمان می‌شود. حذف image، volume یا داده برای این اصلاح لازم نیست.

به‌روزرسانی ظاهر به درخواست مالک: ایران‌سنس محلی، افزایش خوانایی متن‌ها، حذف منبع و یادداشت‌های فنی تکراری از صفحات اصلی، ساده‌سازی صفحه ورود و انتقال جزئیات محیط به تنظیمات. نشان نسخه آزمایشی و وضعیت واقعی اتصال‌ها حفظ شده‌اند.

## رفع 502 پس از بازسازی API
Nginx اکنون نام api را از DNS داخلی Docker با TTL پنج‌ثانیه‌ای دوباره resolve می‌کند؛ آدرس IP اولیه برای همیشه نگه داشته نمی‌شود. healthcheck سرویس web از مسیر واقعی Nginx به health/ready API عبور می‌کند تا running بودن صرف Nginx به‌عنوان آمادگی کل مسیر گزارش نشود. 502 ممکن است علت‌های دیگری هم داشته باشد و برای تشخیص ماشین کاربر logs لازم است.
