# وضعیت ادامه کار
- مخزن مبنا و MIT/TRANSPARENCY ممیزی، SHA pin و کل vendor همراه پروژه شد.
- هسته DB/مهاجرت/seed/API/احراز هویت/worker/پیشنهاد/تأیید/رزرو/سفارش/تحویل پیاده شد.
- SPA ده صفحه فارسی به API واقعی وصل؛ font محلی و جدول جایگزین نقشه.
- import CSV/XLSX preview و commit محدود، OR-Tools synthetic routing، economics calculator و benchmark synthetic.
- تست‌ها و build واقعی در reports؛ برای وضعیت نهایی به فایل‌های خروجی رجوع کنید.
- اتصال‌های واقعی و قابلیت‌های ناتمام در BLOCKERS.fa.md. هیچ production deployment، push به GitHub، ارسال به مشتری یا ثبت در ERP انجام نشده است.

ادامه از همین سورس؛ stack را بدون ADR عوض نکنید. محیط cloud ایزوله است؛ از checkout موجود استفاده کنید و بدون درخواست صریح worktree نسازید. پس از بازیابی فرآیند API/worker باید دوباره شروع شود.

اصلاح سازگاری Windows PowerShell 5.1: bootstrap.ps1 با UTF-8 BOM ذخیره شد تا متن فارسی به‌اشتباه ANSI خوانده نشود. اجرای مستقیم PowerShell روی ویندوز در محیط Linux تست نشده است؛ بررسی بایت BOM و برابری متن انجام شد.

اصلاح نصب روی شبکه کند: timeout دریافت pip به ۱۸۰ ثانیه و retries به ۸ افزایش یافت؛ بررسی TLS و require-hashes حفظ شد. این تغییر رفع قطعی اختلال اینترنت یا proxy را تضمین نمی‌کند.
