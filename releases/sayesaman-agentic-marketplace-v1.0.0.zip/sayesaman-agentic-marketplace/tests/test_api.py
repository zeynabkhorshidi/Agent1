from datetime import date,timedelta
from packages.agents.runner import process_one
from packages.domain.models import *

def login(c,name):
    d=c.post('/api/v1/auth/login',json={'username':name,'password':'test-password-long'}).json();c.headers['X-CSRF-Token']=d['csrf_token']

def test_full_persian_flow(client):
    c=client
    r=c.post('/api/v1/purchase-intents',json={'store_id':'demo-store-01','text':'یک کارتن شربت پرتقال','lines':[{'sku':'demo-sku-01','quantity':1,'unit':'carton'}],'budget_rial':10000000,'delivery_day':str(date.today()+timedelta(days=1))});assert r.status_code==200,r.text
    intent=r.json(); assert c.post(f"/api/v1/purchase-intents/{intent['id']}/validate").status_code==200
    run=c.post('/api/v1/agent-runs',json={'intent_id':intent['id']}).json();assert process_one()
    job=c.get('/api/v1/agent-runs/'+run['id']).json(); assert job['status']=='completed'
    p=c.get('/api/v1/records/proposal').json()[0]; a=c.get('/api/v1/records/approval').json()[0]
    assert c.post('/api/v1/approvals/'+a['id']+'/decide',json={'expected_version':a['version'],'terms_hash':p['data']['terms_hash'],'approve':True}).status_code==200
    order=c.post('/api/v1/proposals/'+p['id']+'/accept',json={'expected_version':p['version'],'terms_hash':p['data']['terms_hash']},headers={'Idempotency-Key':'e2e-test-key'}); assert order.status_code==200,order.text
    oid=order.json()['id']
    for version,target in [(1,'dispatched'),(2,'delivered')]: assert c.post(f'/api/v1/orders/{oid}/transition',json={'expected_version':version,'target':target}).status_code==200
    assert c.get('/api/v1/orders/'+oid).json()['status']=='delivered'

def test_customer_scope_and_private_cost(client):
    login(client,'customer')
    assert len(client.get('/api/v1/records/store').json())==1
    assert client.get('/api/v1/inventory').status_code==403
    assert client.get('/api/v1/records/import').status_code==403
    data=client.get('/api/v1/catalog/products').json(); assert 'cost' not in data['items'][0]
    payload={'store_id':'demo-store-02','text':'x','lines':[],'budget_rial':100,'delivery_day':str(date.today()+timedelta(days=1))}
    assert client.post('/api/v1/purchase-intents',json=payload).status_code==403

def test_viewer_cannot_write_and_csrf(client):
    login(client,'viewer'); assert client.post('/api/v1/voice/sessions').status_code==503
    assert client.post('/api/v1/agent-runs',json={'intent_id':'missing'}).status_code==403
    client.headers.pop('X-CSRF-Token'); assert client.put('/api/v1/settings',json={'kill_switch':True,'name':'x'}).status_code==403

def test_validation_no_stack_and_voice_failure(client):
    r=client.post('/api/v1/purchase-intents',json={'bad':'data'}); assert r.status_code==422 and r.json()['error_code']=='VALIDATION'
    r=client.post('/api/v1/voice/sessions'); assert r.status_code==503 and r.json()['error_code']=='VTT_UNVERIFIED'

def test_live_provider_fails_honestly(client):
    from tests.test_domain import quote
    from packages.domain.core import record,validate_intent
    with DB.begin() as db:
        u=db.get(User,'admin'); i=record(db,u,'intent',{'lines':[{'sku':'demo-sku-01','quantity':1,'unit':'each'}],'budget_rial':1000000,'delivery_day':'2027-01-01'},'draft','demo-store-01');validate_intent(db,u,i);iid=i.id
    r=client.post('/api/v1/agent-runs',json={'intent_id':iid,'provider':'live'}).json();process_one()
    job=client.get('/api/v1/agent-runs/'+r['id']).json();assert job['status']=='failed' and job['data']['error_code']=='NO_PROVIDER'
