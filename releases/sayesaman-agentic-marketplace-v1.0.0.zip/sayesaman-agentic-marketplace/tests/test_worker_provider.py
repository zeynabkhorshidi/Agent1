import os,json
from concurrent.futures import ThreadPoolExecutor
from sqlalchemy import select
import pytest
from packages.domain.core import *
from packages.agents.runner import process_one
from packages.integrations.llm import LLMGateway

def test_worker_many_claims_and_restart():
    with DB.begin() as db:
        u=db.get(User,'admin')
        for _ in range(20):
            i=record(db,u,'intent',{'lines':[{'sku':'demo-sku-01','quantity':1,'unit':'each'}],'budget_rial':1000000,'delivery_day':'2027-01-01'},'draft','demo-store-01');validate_intent(db,u,i)
            record(db,u,'run',{'actor':'admin','intent_id':i.id},'queued','demo-store-01')
    # Each invocation models a restarted worker; one invocation processes one persisted job.
    for _ in range(20): assert process_one()
    assert not process_one()
    with DB() as db: assert len(db.scalars(select(Record).where(Record.kind=='run',Record.status=='completed')).all())==20

def test_llm_untrusted_invalid_output(monkeypatch):
    monkeypatch.setenv('LLM_BASE_URL','https://model.example/v1');monkeypatch.setenv('LLM_MODEL','test-pinned');monkeypatch.setenv('LLM_API_KEY','synthetic-test-key');monkeypatch.setenv('LLM_ALLOWED_HOSTS','model.example')
    class FakeResponse:
        status_code=200
        def json(self): return {'choices':[{'message':{'content':json.dumps({'action':'run_shell','evidence_ids':['sku'],'summary_fa':'دستور ناامن'})}}]}
    class FakeClient:
        def __init__(self,**kwargs):pass
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def post(self,*a,**kw): return FakeResponse()
    monkeypatch.setattr('packages.integrations.llm.httpx.Client',FakeClient)
    with pytest.raises(DomainError) as e: LLMGateway().suggest([{'sku':'sku'}])
    assert e.value.code=='MODEL_OUTPUT'

def test_worker_expired_reservation_and_outbox():
    from tests.test_domain import quote
    from services.worker.main import maintenance
    with DB.begin() as db:
        p=quote(db);u=db.get(User,'admin');r=accept(db,u,p.id,1,p.data['terms_hash'],'maintenance-test-key');order=db.get(Record,r['id']);order.data={**order.data,'reservation_expires':'2000-01-01T00:00:00+00:00'};oid=order.id
    maintenance();maintenance()
    with DB() as db:
        assert db.get(Record,oid).status=='expired'
        assert sum(s.reserved for s in db.scalars(select(Stock)))==0
        assert all(r.status=='acknowledged' for r in db.scalars(select(Record).where(Record.kind=='outbox')))

def test_non_demo_mutations_disabled(client,monkeypatch):
    monkeypatch.setenv('APP_MODE','shadow')
    r=client.post('/api/v1/routes/plan',json={'store_ids':['demo-store-01']});assert r.status_code==403 and r.json()['error_code']=='MODE_DISABLED'
