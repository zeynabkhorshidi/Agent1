import os
os.environ.setdefault('DATABASE_URL','sqlite:///./test-ledger.db')
import pytest
from fastapi.testclient import TestClient
from packages.domain.models import Base,engine,DB,User
from packages.domain.seed import seed
from packages.domain.core import password_hash
from services.api.main import app
@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(engine); Base.metadata.create_all(engine)
    with DB.begin() as db:
        seed(db)
        for name,role,store in [('admin','admin',None),('customer','customer','demo-store-01'),('other','customer','demo-store-02'),('viewer','viewer',None)]:
            db.add(User(id=name,password=password_hash('test-password-long'),role=role,store_id=store))
    yield
@pytest.fixture
def client():
    with TestClient(app) as c:
        d=c.post('/api/v1/auth/login',json={'username':'admin','password':'test-password-long'}).json(); c.headers['X-CSRF-Token']=d['csrf_token']; yield c
