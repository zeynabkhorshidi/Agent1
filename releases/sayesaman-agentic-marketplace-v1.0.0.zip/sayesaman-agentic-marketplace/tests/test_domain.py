from concurrent.futures import ThreadPoolExecutor
from datetime import date,timedelta
import pytest
from sqlalchemy import select,update
from packages.domain.core import *
from packages.domain.seed import seed
from packages.domain.routing import plan,coalition
from packages.integrations.catalog import preview,commit_import
from packages.agents.upstream import evidence_message

def quote(db,user='admin',store='demo-store-01',qty=12):
    u=db.get(User,user)
    r=record(db,u,'intent',{'lines':[{'sku':'demo-sku-01','quantity':qty,'unit':'each'}],'budget_rial':100000000,'delivery_day':str(date.today()+timedelta(days=1))},'draft',store)
    validate_intent(db,u,r); p=issue_quote(db,u,r)
    a=next(x for x in db.scalars(select(Record).where(Record.kind=='approval')) if x.data['proposal_id']==p.id); a.status='approved'
    return p

def test_money_units_and_normalization():
    assert money('12.25','toman')==123
    assert money('0.5')==1
    assert normalize('  آبميوه\u200cسيب ۱۲ ')=='آبمیوه سیب 12'
    with pytest.raises(DomainError): money(-1)
    with pytest.raises(DomainError): money(1,'unknown')

def test_duplicate_barcode_not_merged():
    with DB() as db:
        rows=db.scalars(select(Product).where(Product.barcode=='6260100600041')).all()
        assert len(rows)==2 and {p.pack for p in rows}=={6,12}

def test_order_idempotence_and_exact_money():
    with DB.begin() as db: p=quote(db); pid,hash=p.id,p.data['terms_hash']
    with DB.begin() as db: result=accept(db,db.get(User,'admin'),pid,1,hash,'same-key-123')
    with DB.begin() as db:
        again=accept(db,db.get(User,'admin'),pid,1,hash,'same-key-123'); assert result==again
        assert sum(s.reserved for s in db.scalars(select(Stock)))==12
        order=db.get(Record,result['id']); assert order.data['total_rial']==1440000; assert order.data['payment_state']=='unpaid'

def test_rollback_when_short():
    with DB.begin() as db: p=quote(db,qty=701); pid,h=p.id,p.data['terms_hash']
    with pytest.raises(DomainError):
        with DB.begin() as db: accept(db,db.get(User,'admin'),pid,1,h,'short-key-123')
    with DB() as db:
        assert sum(s.reserved for s in db.scalars(select(Stock)))==0
        assert len(db.scalars(select(Record).where(Record.kind=='order')).all())==0

@pytest.mark.parametrize('failure',['expiry','version','price','mandate','approval','kill'])
def test_reject_invalid_commit(failure):
    with DB.begin() as db:
        p=quote(db); pid,h=p.id,p.data['terms_hash']
        if failure=='expiry': p.data={**p.data,'expires':'2000-01-01T00:00:00+00:00'}
        if failure=='price': db.get(Product,'demo-sku-01').version+=1
        if failure=='mandate': db.get(Record,'demo-mandate-01').status='revoked'
        if failure=='approval':
            for a in db.scalars(select(Record).where(Record.kind=='approval')): a.status='pending'
        if failure=='kill': db.get(Setting,'control').value={'kill_switch':True}
    with pytest.raises(DomainError):
        with DB.begin() as db: accept(db,db.get(User,'admin'),pid,2 if failure=='version' else 1,h,'reject-key-123')

def test_concurrent_last_stock():
    with DB.begin() as db:
        db.execute(update(Stock).where(Stock.sku=='demo-sku-01').values(on_hand=0))
        db.get(Stock,'demo-sku-01-w0').on_hand=12
        p1=quote(db); p2=quote(db,store='demo-store-02'); pairs=[(p.id,p.data['terms_hash']) for p in (p1,p2)]
    def buy(pair):
        try:
            with DB.begin() as db: accept(db,db.get(User,'admin'),pair[0],1,pair[1],pair[0]); return 'ok'
        except DomainError: return 'rejected'
    with ThreadPoolExecutor(2) as pool: results=list(pool.map(buy,pairs))
    assert results.count('ok')==1
    with DB() as db: assert db.get(Stock,'demo-sku-01-w0').reserved==12

def test_fulfill_release_and_expiry():
    with DB.begin() as db:
        p=quote(db); u=db.get(User,'admin'); res=accept(db,u,p.id,1,p.data['terms_hash'],'fulfill-test-key'); order=db.get(Record,res['id']); fulfill(db,u,order,'dispatched'); fulfill(db,u,order,'delivered')
        assert db.get(Stock,'demo-sku-01-w0').on_hand==288
        assert db.get(Stock,'demo-sku-01-w0').reserved==0
        with pytest.raises(DomainError): fulfill(db,u,order,'dispatched')

def test_import_atomic_idempotent_and_malicious():
    content=b'code,name,barcode,pack,price_rial,cost_rial\nTEST,Test,123,6,100,80\n'
    a=preview(content,'safe.csv'); assert not a['errors']
    with DB.begin() as db:
        u=db.get(User,'admin'); job=record(db,u,'import',a,'preview'); commit_import(db,u,job); commit_import(db,u,job)
        assert len(db.scalars(select(Product).where(Product.code=='TEST')).all())==1
    bad=preview(b'code,name,barcode,pack,price_rial,cost_rial\n=BAD,Test,123,0,100,80\n','bad.csv'); assert bad['errors']

def test_upstream_protocol_reused():
    msg=evidence_message({'evidence_ids':['sku-1'],'summary':'پیشنهاد مشروط'})
    assert msg['type']=='text' and 'evidence_ids' in msg['content']

def test_group_negative_and_sum():
    assert not coalition(10,20)['accepted']
    r=coalition(101,0); assert r['customer_share_rial']+r['distributor_share_rial']==101

def test_routing_capacity_and_infeasible():
    stores=[{'id':'a','data':{'lat':35.70,'lon':51.40,'name':'آزمایشی','window':[480,600]}},{'id':'b','data':{'lat':35.71,'lon':51.41,'name':'آزمایشی','window':[480,600]}}]
    vehicles=[{'id':'v','data':{'capacity_units':15,'shift':[480,1080]}}]
    r=plan(stores,vehicles,{'lat':35.69,'lon':51.39})
    assert len(r['unserved'])==1
    assert sum(s['load_units'] for s in r['routes'][0]['stops'])<=15
    assert plan(stores,[],{})['status']=='infeasible'
