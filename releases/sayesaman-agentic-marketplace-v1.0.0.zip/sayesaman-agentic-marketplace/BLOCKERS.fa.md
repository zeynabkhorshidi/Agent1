# موانع و کارهای باقی‌مانده
## ورودی‌های بیرونی
- کاتالوگ عمومی از این محیط: HTTP CONNECT 403. صفر SKU استخراج و تأییدشده جدید. export رسمی CSV/XLSX ترجیح دارد.
- ERP/WMS/credit/pricebook/tax و master packaging/expiry واقعی ارائه نشده‌اند. برای ادامه قرارداد read/write، کلید محدود sandbox و نمونه پاسخ لازم است.
- VTT develop/prod فقط host/port دارد؛ protocol/path/auth/codec/sample-rate/finalization و دسترسی مجاز لازم است. هیچ probe خصوصی یا تست prod انجام نشده.
- نقشه/ماتریس خیابانی و ترافیک provider قراردادی ندارد.
- مدل زنده، مدل نسخه‌دار، دسترسی HTTPS مجاز، کلید سمت سرور و تعرفه ارائه نشده؛ gateway optional و fail-closed است.

## کمبودهای اجرایی که صرفاً مانع بیرونی نیستند
گروه چندطرفه و counteroffer/saga کامل، نرمال‌سازی همه entityها، ۹ نقش/OIDC، mandate روزانه/SKU، reservation renewal/reconciliation، DLQ و ERP partial failure، locked route stops/multi-depot/weight-volume، import mapping/resume بزرگ/rollback پس از commit، PDF/async exports، presentation replay و ارزیابی جامع فارسی مدل هنوز تکمیل نشده‌اند. نباید آن‌ها را با نبود credential توجیه یا «آماده» اعلام کرد.

این تحویل یک دموی تراکنشی قابل بررسی است؛ اجرای دقیق و کامل همه بندهای master prompt هنوز حاصل نشده. مسیر بعدی: اول داده و قرارداد sandbox؛ سپس تکمیل جدول پذیرش و آزمون staging پیش از پایلوت.
