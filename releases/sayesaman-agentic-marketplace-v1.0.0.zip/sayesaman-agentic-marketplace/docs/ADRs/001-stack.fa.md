# ADR 001: modular monolith
وضعیت: پذیرفته برای دمو.
FastAPI + SQLAlchemy + PostgreSQL و worker تراکنشی؛ React/Vite به جای Next برای SPA هم‌مبدأ بدون SSR انتخاب شد. SEO برای فضای احراز هویت‌شده لازم نیست؛ static build اجرای بدون اینترنت را ساده می‌کند. هزینه: تولید client از OpenAPI هنوز خودکار نشده است. TypeScript مدل‌های مشترک خواندن و wrapper typed را دارد، اما تمام قراردادها کاملاً تولیدشده نیستند.
SQL-backed queue از نصب Redis و broker اضافی جلوگیری می‌کند. CPU سنگین solver محدود به ۲ ثانیه است. از اضافه‌کردن framework ایجنتی دوم خودداری شد.
