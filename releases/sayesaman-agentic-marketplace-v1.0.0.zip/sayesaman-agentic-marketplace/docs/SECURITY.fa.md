# امنیت و دسترسی
| نقش | مشاهده | نوشتن |
|---|---|---|
| admin | همه داده دمو شعبه/سازمان | خرید، import، تنظیمات، انبار |
| sales | فروش و موجودی | نیاز/پیشنهاد/مسیر |
| warehouse | موجودی و سفارش‌های شعبه | dispatch/delivery و مسیر |
| customer | فقط store_id خودش؛ بدون cost | نیاز، تأیید و سفارش خودش، revoke |
| viewer | نمایش پرونده‌های مجاز | نوشتن خرید ممنوع |

هسته scope tenant/branch/store را در API enforce می‌کند. دیتابیس/pgAdmin روی اینترنت publish نیست. بارکدهای مشترک حفظ شده‌اند. session cookie HttpOnly/SameSite Strict و توکن CSRF header برای درخواست‌های تغییردهنده؛ login محدودیت ده تلاش در دقیقه/IP دارد (حافظه محلی، distributed نیست). PBKDF2-SHA256 با salt و ۳۱۰هزار دور. هیچ رمز پیش‌فرضی وجود ندارد. COOKIE_SECURE=true و TLS reverse proxy برای محیط سازمانی لازم است.

Upload فقط CSV/XLSX با محدودیت اندازه، formula و کد؛ URL fetch دلخواه پشتیبانی نمی‌شود تا SSRF نشود. React متن را escape می‌کند. Secret در frontend یا پاسخ health وجود ندارد. log شامل method/path/status/duration/correlation است، نه body/password. CSP و nosniff و frame deny برقرار است.

Retentions فعلی: session هشت ساعت (انقضا بررسی، purge زمان‌بندی‌شده هنوز نیست)، صوت خام ذخیره نمی‌شود؛ داده دمو تا reset دستی نگهداری می‌شود. سیاست retention و رمزگذاری backup عملیاتی باید توسط شرکت مصوب شود. OIDC، ۹ نقش سازمانی، security review مستقل، redaction جامع diagnostics و تست penetration انجام نشده‌اند. این نسخه برای exposure عمومی یا production تأیید نشده است.
