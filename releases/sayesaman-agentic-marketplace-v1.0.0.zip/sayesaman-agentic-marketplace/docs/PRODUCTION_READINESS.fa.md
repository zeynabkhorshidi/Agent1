# آمادگی عملیاتی
این محصول آماده production یا پایلوت واقعی اعلام نمی‌شود. demo قابل اجرا و تست هسته دارد؛ تمام سند سفارش هنوز پذیرش نشده است.

| قابلیت | وضعیت |
|---|---|
| جریان درخواست تا سفارش/تحویل دمو، پول integer، stock atomic | پیاده‌سازی و تست‌شده |
| UI فارسی/RTL و asset محلی، login و RBAC محدود | پیاده‌سازی؛ browser evidence در reports |
| worker و outbox محلی و TTL | پیاده‌سازی؛ ERP نیست |
| OR-Tools و جدول تقریبی و حذف خودرو | دمو؛ مسیر عملیاتی نیست |
| LLMGateway اختیاری | پیاده‌سازی؛ اتصال زنده تست‌نشده |
| VTT/ERP/WMS/نقشه/کاتالوگ کامل | مسدود به قرارداد/داده/دسترسی |
| گروه‌سازی چندطرفه و negotiation محدود واقعی | ناتمام؛ فقط ارزیابی اقتصادی مستقل |
| چندانبار، وزن/حجم، locked stops و cold chain | ناتمام |
| OIDC، نقش‌های کامل، saga/DLQ/reconciliation، security review | ناتمام |
| PDF سازمانی/async scoped exports و presentation replay | ناتمام |
| shadow/pilot واقعی | فعال نیست؛ نوشتن بیرونی وجود ندارد |

پیش از پایلوت: تعیین مسئول عملیات، قرارداد داده و اتصال، تکمیل قیود و mandate کامل، staging، آزمون failure و rollback/backup، ارزیابی امنیت و پذیرش کتبی شرکت. تغییر فلگ UI مجوز live write ایجاد نمی‌کند. گزارش تست skipped/unrun را passed نشمارید.
