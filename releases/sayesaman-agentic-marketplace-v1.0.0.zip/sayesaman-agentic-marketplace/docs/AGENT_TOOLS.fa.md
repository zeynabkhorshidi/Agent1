# عامل و ابزار
عامل قطعی demo با workflow محدود: resolve_sku → get_price_quote → request_approval. خروجی شامل evidence_ids و مدل مصرف صفر است. وضعیت queued/completed/failed/cancelled پایدار است. سفارش تنها از domain service و تأیید نسخه عبور می‌کند؛ مدل SQL/shell/URL ورودی کاربر اجرا نمی‌کند.

LLMGateway اختیاری OpenAI-compatible برای sandbox: LLM_BASE_URL، LLM_MODEL نسخه‌دار، LLM_API_KEY و LLM_ALLOWED_HOSTS سمت سرور. HTTPS، allowlist، timeout بیست ثانیه، concurrency چهار و حداکثر ۴۰۰ token خروجی. خروجی action=request_quote|needs_review، evidence_ids و summary_fa با Pydantic validate می‌شود. هزینه بدون جدول قیمت null است. شبکه/JSON نامعتبر به خطای typed ختم می‌شود؛ تعمیر و retry خودکار انجام نمی‌شود. provider زنده در این تحویل اجرا نشده است.

Mandate دمو: principal فروشگاه، مبلغ سفارش، expiry و وضعیت active/revoked. لغو و accept همان row lock را می‌گیرند. بررسی بودجه intent، قیمت تازه، approval/hash/version و expiry قطعی است. سقف روزانه، SKU allowlist، substitution پیشرفته، negotiation چنددوره، memory و budget token تجمعی هنوز کامل نیستند؛ از این رو اجرای محدود بی‌تأیید فعال نیست. خروجی UI خلاصه شاهد ابزار است، نه chain-of-thought.
