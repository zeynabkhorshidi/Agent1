# خطاهای نصب مشاهده‌شده

## Windows PowerShell و متن فارسی
اسکریپت bootstrap.ps1 با UTF-8 BOM ذخیره می‌شود. برای اصلاح نسخه قدیمی، فایل را با UTF-8 بخوانید و با UTF8Encoding(true) بنویسید؛ متن فارسی نباید به ANSI تبدیل شود. کپی اصلی .env را تغییر ندهید.

## pip ReadTimeoutError
اگر build با `HTTPSConnectionPool(host='files.pythonhosted.org', port=443): Read timed out` متوقف شد، این یک timeout دانلود است؛ با خطای نسخه dependency یا خطای اجرای برنامه یکی نیست. نسخه اصلاح‌شده Dockerfile، `--timeout 180 --retries 8` را به pip می‌دهد و `--require-hashes` و TLS را حفظ می‌کند. این timeout مهلت انتظار شبکه است، نه محدودیت زمان کل نصب. اینترنت/پروکسی Docker باید به pypi.org و files.pythonhosted.org دسترسی داشته باشد. تکرار timeout پس از این تغییر نیاز به بررسی همان اتصال یا تنظیم proxy مجاز Docker Desktop دارد.

پس از اصلاح، bootstrap را دوباره اجرا کنید؛ لایه‌های موفق Docker می‌توانند از cache استفاده شوند. پیام npm audit در خروجی گزارش‌شده علت شکست build نبود؛ برای ارزیابی آن، audit جداگانه و اصلاح هدفمند dependency لازم است. `npm audit fix --force` بدون بررسی اجرا نشود.
