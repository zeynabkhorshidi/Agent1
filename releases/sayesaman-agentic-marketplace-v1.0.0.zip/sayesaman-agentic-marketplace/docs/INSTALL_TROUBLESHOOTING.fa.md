# خطاهای نصب مشاهده‌شده

## Windows PowerShell و متن فارسی
اسکریپت bootstrap.ps1 با UTF-8 BOM ذخیره می‌شود. برای اصلاح نسخه قدیمی، فایل را با UTF-8 بخوانید و با UTF8Encoding(true) بنویسید؛ متن فارسی نباید به ANSI تبدیل شود. کپی اصلی .env را تغییر ندهید.

## pip ReadTimeoutError
اگر build با `HTTPSConnectionPool(host='files.pythonhosted.org', port=443): Read timed out` متوقف شد، این یک timeout دانلود است؛ با خطای نسخه dependency یا خطای اجرای برنامه یکی نیست. نسخه اصلاح‌شده Dockerfile، `--timeout 180 --retries 8` را به pip می‌دهد و `--require-hashes` و TLS را حفظ می‌کند. این timeout مهلت انتظار شبکه است، نه محدودیت زمان کل نصب. اینترنت/پروکسی Docker باید به pypi.org و files.pythonhosted.org دسترسی داشته باشد. تکرار timeout پس از این تغییر نیاز به بررسی همان اتصال یا تنظیم proxy مجاز Docker Desktop دارد.

پس از اصلاح، bootstrap را دوباره اجرا کنید؛ لایه‌های موفق Docker می‌توانند از cache استفاده شوند. پیام npm audit در خروجی گزارش‌شده علت شکست build نبود؛ برای ارزیابی آن، audit جداگانه و اصلاح هدفمند dependency لازم است. `npm audit fix --force` بدون بررسی اجرا نشود.

## ساخت هم‌زمان image مشترک
در برخی نسخه‌های Docker Desktop/BuildKit، سه build هم‌زمان برای یک tag با image already exists شکست می‌خورند. فقط api تنظیم build دارد؛ migrate و worker همان image را مصرف می‌کنند. bootstrap نخست `docker compose build api` و پس از موفقیت `docker compose up -d --no-build --wait api worker web` را اجرا می‌کند. فلگ `--no-build` در مرحله دوم مانع build هم‌زمان می‌شود. حذف image، volume یا داده برای این اصلاح لازم نیست.

## رفع 502 پس از بازسازی API
Nginx اکنون نام api را از DNS داخلی Docker با TTL پنج‌ثانیه‌ای دوباره resolve می‌کند؛ آدرس IP اولیه برای همیشه نگه داشته نمی‌شود. healthcheck سرویس web از مسیر واقعی Nginx به health/ready API عبور می‌کند تا running بودن صرف Nginx به‌عنوان آمادگی کل مسیر گزارش نشود. 502 ممکن است علت‌های دیگری هم داشته باشد و برای تشخیص ماشین کاربر logs لازم است.
