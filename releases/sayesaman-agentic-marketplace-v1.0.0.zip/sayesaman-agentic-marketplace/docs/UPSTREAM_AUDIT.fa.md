# ممیزی upstream
مخزن: microsoft/multi-agent-marketplace؛ checkout واقعی در ۲۰۲۶/۱۱/۰۳. SHA دقیق در UPSTREAM_COMMIT.txt: `9a651c7632685e4aeb2956dfe315df0cec6e8a92`. این SHA هنگام دریافت HEAD بود؛ ادعای آخرین نسخه در آینده نیست.

README، LICENSE (MIT)، TRANSPARENCY، pyproject ریشه و package، agents/protocol docs، messaging.py، shared/models.py و فهرست tests خوانده شد. upstream به Python >=3.11 نیاز دارد؛ محصول با Python 3.12.14 ساخته و تست شد. workspace با uv و CLI magentic-marketplace است. compose upstream جایگزین compose کامل محصول نیست. CustomerAgent/BusinessAgent چرخه step دارند. مدل‌های نمونه menu_features و float برای پول SKU مناسب نیستند. TRANSPARENCY صریحاً کاربرد تجاری مستقیم را خارج از دامنه می‌داند.

| جزء | تصمیم | اجرای واقعی |
|---|---|---|
| TextMessage و MessageAdapter | استفاده مجدد از فایل بدون تغییر | worker پیام شاهد می‌سازد؛ round-trip در تست integration |
| float OrderProposal و Payment | جایگزینی در تراکنش | پیشنهاد integer ریال و payment_state=unpaid |
| Customer/Business loop | جدا و نگهداری پژوهشی | worker پایدار مبتنی بر رکورد DB |
| search و experiment framework کامل | همراه vendor، استفاده‌نشده | نصب/تست کامل upstream ادعا نمی‌شود |

دستورها: git clone، git rev-parse HEAD، خواندن اسناد، اجرای `evidence_message`، pytest تست adapter. import عادی package به importهای جانبی runtime و aiohttp وابسته بود؛ ADR-002 بارگذاری مستقیم ماژول مستقل messaging با importlib را انتخاب کرد. هیچ فایل upstream patch نشده است. کل سورس upstream، tests و مجوز داخل vendor موجود است؛ .git و cache حذف می‌شوند. مجموعه کامل تست upstream اجرا نشده؛ گزارش تست محصول با تست upstream یکی نیست.
