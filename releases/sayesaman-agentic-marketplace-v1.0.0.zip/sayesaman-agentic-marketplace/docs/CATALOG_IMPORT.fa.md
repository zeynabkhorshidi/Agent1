# ورود کاتالوگ
Template CSV UTF-8 BOM و XLSX در data/demo. UI مدیر: تنظیمات → انتخاب فایل → بررسی شمارش و خطاها → ثبت. API preview و commit جداست. محدودیت دو مگابایت، هزار ردیف، محدودیت حجم decompressed XLSX و رد فرمول. واردسازی content-addressed با SHA256 است؛ ارسال همان فایل همان job را برمی‌گرداند. کد تکراری یا موجود conflict است و بازنویسی خاموش ندارد. قیمت و نام سفارش قبلی snapshot هستند.

ستون‌ها: code,name,barcode,pack,price_rial,cost_rial. کد/بارکد رشته‌اند. صفر ابتدای بارکد در Excel باید Text باشد. وزن ناشناخته null است؛ وزن نمونه 780GR/786G به‌صورت conflict خام در provenance نمونه‌ها باقی مانده و به CC تبدیل نشده است. قیمت و cost فایل صرفاً در sandbox دمو قرار می‌گیرد.

Coverage: ۳۰ fixture، صفر SKU تأییدشده از استخراج جدید، ۸ نمونه سند تأییدنشده، ۲۲ ساختگی. تاریخ نمونه‌ها از سند مالک است، زمان extraction جدید ادعا نمی‌شود. robots و شرایط سایت بررسی نشده چون اتصال با 403 رد شد؛ scraping یا endpoint حدسی انجام نشد.

توقف/ادامه preview در DB پایدار است؛ commit یک تراکنش کامل است، نه stream بزرگ. wizard mapping آزاد، rollback منطقی پس از commit و نگهداری raw binary کامل هنوز پیاده نشده‌اند؛ hash و نام و rows در ImportJob ذخیره می‌شود. برای اصلاح کد موجود روند بازبینی جدا لازم است.
