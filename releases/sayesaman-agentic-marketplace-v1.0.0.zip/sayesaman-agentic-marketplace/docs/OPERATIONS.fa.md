# عملیات
شروع: bootstrap؛ سلامت: `docker compose ps` و `/api/v1/health/ready`. worker باید جدا روشن باشد؛ PID API به‌تنهایی آمادگی workflow نیست. metric پایه در log JSON هر درخواست شامل duration/status/correlation است؛ Prometheus/tracing کامل موجود نیست.

Backup: `bash scripts/backup.sh /مسیر/امن/demo.dump`؛ فایل با umask 077 نوشته می‌شود و رمزگذاری نشده، پس فقط محل محافظت‌شده. Restore روی دمو: `bash scripts/restore.sh /مسیر/امن/demo.dump --replace-demo`. سرویس‌های نویسنده پیش از restore متوقف می‌شوند. RPO/RTO قراردادی تعیین نشده؛ آزمایش restore در reports ثبت می‌شود.

Migration: `alembic upgrade head`. migration اولیه ایجاد جدول؛ downgrade آن destructive است، برای recovery داده از backup تست‌شده استفاده کنید. پیش از تغییر schema snapshot و پس از release smoke و مسیر خرید تا تحویل اجرا شود. از اجرای pytest روی دیتابیس دارای داده مهم خودداری کنید: fixture جدول‌ها را drop می‌کند. load فقط DB با نام sayesaman_load را قبول می‌کند.

قطع VTT/ERP/نقشه: قابلیت بیرونی disconnected بماند، ورود متنی و دفتر دمو ادامه یابد؛ موفقیت sync نمایش ندهید. مدل timeout/invalid-output به بررسی انسانی ختم شود. توقف اضطراری مدیر ثبت/accept عامل را می‌بندد، مشاهده و رسیدگی سفارش‌های موجود مجاز می‌ماند. اختلاف موجودی: commit متوقف، رکورد و correlation بررسی، سپس منبع WMS reconcile شود؛ اصلاح دستی عدد بدون audit مجاز نیست.

این ZIP backup داده نیست. diagnostics عمومی شامل credential، transcript خصوصی یا env dump نباید باشد. بازبینی فایل گزارش قبل از اشتراک الزامی است.
