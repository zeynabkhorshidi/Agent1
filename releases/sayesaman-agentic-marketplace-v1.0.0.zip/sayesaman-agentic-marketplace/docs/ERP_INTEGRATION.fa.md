# ERP/WMS: disconnected
interfaces در packages/integrations/providers.py. sink محلی outbox فقط demo-ledger را acknowledge می‌کند؛ ارسال بیرونی ندارد. سفارش با erp_status=not_sent و payment_state=unpaid ذخیره می‌شود. پذیرش پیشنهاد هیچ تسویه‌ای ایجاد نمی‌کند.

قرارداد پیشنهادی، نه قرارداد کشف‌شده: request شامل external_client_order_id، idempotency_key، store_mapping، sku/unit mapping، pricebook_version، lines، rial totals، requested_delivery و expected_version؛ response شامل external_order_id، status، accepted_version و rejected_lines. مسیر HTTP مشخص نشده و حدس زده نمی‌شود. webhook نیاز به امضای معتبر، replay window و scope دارد.

قبل از پایلوت: API رسمی، WMS batch/expiry و credit، tax، timeout/retry/idempotency، reconciliation و compensation بر اساس خطای partial بررسی شوند. پذیرش outbox محلی تضمین exactly-once جهانی نیست. retry/DLQ واقعی ERP و saga چندطرفه هنوز تکمیل نشده‌اند.
