# ماتریس پذیرش سند
| بخش سند | حاصل تحویل | وضعیت |
|---|---|---|
| ۱–۴ معماری/upstream/حالت‌ها | audit، reuse واقعی پیام، ledger دمو؛ live modes مسدود | جزئی |
| ۵ UI | ده صفحه RTL متصل؛ نیاز به accessibility audit جامع و گزارش PDF | جزئی |
| ۶ معماری | modular monolith + worker + Postgres + migration + solver | دمو آماده |
| ۷ import | CSV/XLSX preview/commit، hash/conflict؛ mapping/rollback بزرگ ندارد | جزئی |
| ۸ مدل داده | SKU/stock/users/events مستقل؛ سایر aggregates JSON نسخه‌دار | جزئی |
| ۹ عامل | قطعی ۳ ابزار و gateway اختیاری؛ ۶ نقش کامل نیست | جزئی |
| ۱۰ گروه/مذاکره | economics calculator؛ تعهد چندطرفه/negotiation نیست | ناتمام |
| ۱۱ تراکنش | row lock، conditional update، hash/version، TTL، سفارش مستقل | هسته دمو تست‌شده؛ saga خارجی نیست |
| ۱۲ routing | CVRP زمان/ظرفیت واحد، fixture؛ multi-depot/locked stops نیست | جزئی |
| ۱۳–۱۵ اتصال‌ها | interface/fail-closed/gateway optional | اتصال واقعی تأییدنشده |
| ۱۶ امنیت | local auth/CSRF/scope، ۵ نقش؛ OIDC/۹ نقش کامل نیست | جزئی |
| ۱۷ API/SSE | OpenAPI و cursor/scoped replay | دمو؛ endpoints کامل سند نیست |
| ۱۸ سناریو | workflow UI و تست‌های شکست؛ presentation replay نیست | جزئی |
| ۱۹ ارزیابی | A/B/C_demo با hash؛ C_live unrun و ROI نامشخص | جزئی |
| ۲۰ تست | هسته/API/Postgres/SQLite، browser/load گزارش جدا | بخشی از gate؛ جامع نیست |
| ۲۱ نصب | compose کامل، bootstrap، backup/restore، dependency locks | شواهد اجرا در reports |
| ۲۲–۲۵ تحویل | ZIP/manifest/secret scan/docs؛ تمام فازها پذیرفته نیستند | تحویل دمو، نه تکمیل تمام قرارداد |
