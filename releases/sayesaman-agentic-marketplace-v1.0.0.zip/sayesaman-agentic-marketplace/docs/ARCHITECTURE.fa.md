# معماری
```mermaid
flowchart RL
 W[رابط فارسی React] --> P[هم‌مبدأ: Nginx]
 P --> A[FastAPI + احراز هویت]
 A --> D[Domain: پول، مجوز، تأیید، رزرو]
 D --> DB[(PostgreSQL)]
 K[worker: claim + checkpoint] --> DB
 K --> D
 K --> U[upstream TextMessage]
 A --> R[OR-Tools: هندسه مصنوعی]
 A --> E[SSE با cursor و scope]
 L[LLMGateway اختیاری sandbox] --> K
```
Modular monolith با worker جدا؛ queue و outbox در PostgreSQL. وضعیت مرجع مالی در Redis نیست؛ Redis لازم نشده است. web در یک image همراه API build می‌شود و سرویس web نقش reverse proxy دارد. live processes در snapshot یا ZIP ذخیره نمی‌شوند.

بسته domain قواعد تراکنشی دارد؛ route handler صرفاً validation و orchestration انجام می‌دهد. select-for-update پیشنهاد/mandate و conditional UPDATE موجودی در یک تراکنش، oversell را کنترل می‌کند. قید DB reserved<=on_hand آخرین دفاع است. worker داخل تراکنش job و پیشنهاد را با هم commit می‌کند؛ crash پیش از commit rollback می‌شود. تحویل outbox محلی idempotent است؛ اتصال ERP/سازوکار reconciliation آن هنوز اجرا نشده.

SQLite برای توسعه آفلاین محدود؛ PostgreSQL برای هم‌زمانی مرجع. Record برای aggregateهای دمو JSON نسخه‌دار است؛ نرمال‌سازی کامل مدل‌های تجاری و قیود FK برای پایلوت باقی است. این انتخاب به‌عنوان مدل نهایی سازمانی معرفی نمی‌شود.
