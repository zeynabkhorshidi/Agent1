# فرهنگ داده و مرجع حقیقت
| داده | مرجع این نسخه | مرجع لازم پایلوت |
|---|---|---|
| SKU/name/barcode/pack | سند تأییدنشده یا fixture | master data تأییدشده شرکت |
| price/cost integer rial | seed مصنوعی | pricebook نسخه‌دار ERP |
| Stock batch/expiry/reserved | دفتر PostgreSQL مصنوعی | WMS + رزرو محلی reconciled |
| Store/warehouse/vehicle مختصات | مصنوعی تهران | عملیات شرکت |
| Proposal items snapshot/hash/expiry | domain service | همان service با منابع تأییدشده |
| Order payment/fulfillment | unpaid / reserved | ERP و دریافت‌های معتبر جدا |
| Route matrix | geodesic مصنوعی | provider قراردادی street/time |
| User/session/mandate | DB scoped | IdentityProvider سازمانی |

Product.id UUID/string دمو مستقل از code کسب‌وکار است؛ barcode یکتا نیست. pack تعداد پایه و مقدار کارتن integer است. وزن/حجم به هم تبدیل نمی‌شوند. price/cost/total integer ریال؛ تومان فقط تبدیل دقیق ×۱۰. stock on_hand/reserved/available با قید عدم منفی. FEFO با حداقل عمر ۷ روز پیش‌فرض دمو؛ تأیید سیاست واقعی لازم است. IDها در seed دمو خوانا هستند؛ IDهای تراکنش UUID هستند. تاریخ‌ها UTC ISO و نمایش تهران/شمسی؛ روز تحویل date مستقل است.

Record kindها: store، mandate، intent، proposal، approval، order، run، route، warehouse، vehicle، import، outbox و control. Scope: tenant/branch/store؛ version و created_at روی رکوردها. Event actor و aggregate و payload و ترتیب seq دارد. پیش‌فرض org/branch دموست. همه entityهای پیشنهادی سند هنوز جدول مستقل نیستند؛ به acceptance matrix رجوع شود.
