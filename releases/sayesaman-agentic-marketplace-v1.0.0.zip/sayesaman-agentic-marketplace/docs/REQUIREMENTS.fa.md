# پرامپت جامع ساخت بازار ایجنتی سایه سمن

نسخه ۱ — تاریخ بررسی منابع: ۲۰۲۶/۱۱/۰۲ — زبان محصول: فارسی — منطقه زمانی: Asia/Tehran

## راه استفاده

این فایل را کامل به Codex یا عامل برنامه‌نویسی بده. از بخش «شروع دستور ساخت» تا «پایان دستور ساخت» مشخصات اجرایی پروژه است. هدف این فایل، سفارش ساخت نرم‌افزار و ZIP کامل آن است؛ خود این فایل نرم‌افزار ساخته‌شده نیست. هیچ ادعایی درباره آماده‌بودن سیستم برای production صرفاً با اجرای این پرامپت معتبر نیست؛ آزمون، اتصال معتبر و پذیرش عملیاتی لازم است.

---

# شروع دستور ساخت

## ۱. نقش، مأموریت و شیوه کار

تو مسئول معماری، پیاده‌سازی کامل، طراحی تجربه کاربری، آزمون و بسته‌بندی یک محصول سازمانی برای «شرکت پخش سایه سمن» در تهران هستی. از ایده به نرم‌افزار قابل‌اجرا برس؛ به ارائه طرح، چند اسکرین‌شات، فایل‌های ناقص یا TODO در مسیر اصلی اکتفا نکن.

نام نمایشی پیشنهادی: «سایه‌سمن | بازار عامل‌های هوشمند»؛ نام فنی: `sayesaman-agentic-marketplace`. نام قابل‌تغییر از تنظیمات باشد. محصول برای ارائه به هلدینگ بزرگ طراحی می‌شود، با تجربه کاربری حرفه‌ای و مسیر مشخص تبدیل به پایلوت واقعی.

هدف: نماینده‌های خرید مشتریان و نماینده فروش پخش، نیازهای پراکنده را به پیشنهادهای هماهنگ، سودآور، قابل‌تأمین و قابل‌تحویل تبدیل کنند. سفارش هر مشتری مستقل بماند؛ تجمیع فقط در شرایط تجاری مجاز، آماده‌سازی و برنامه توزیع باشد. گروه‌سازی نباید حتماً تخفیف ایجاد کند یا به مشتری تحمیل شود.

رابط کاربر، راهنما، خطاها، اعلان‌ها، گزارش‌ها و PDFها کاملاً فارسی و RTL باشند. نام متغیر، مسیر API و اصطلاحات کد می‌توانند انگلیسی باشند. توضیح تصمیم برای کاربر فارسی، کوتاه و متکی به شواهد محاسباتی باشد.

برای تصمیم‌های معمول مهندسی بهترین گزینه قابل‌دفاع را انتخاب و در ADR ثبت کن. برای سؤال‌های غیرمسدودکننده کار را متوقف نکن. اگر اطلاعات حساس یا قرارداد یک integration مجهول است، بخش مستقل را کامل کن و مورد را دقیق در `BLOCKERS.fa.md` بنویس. برای ادامه کار در جلسات بعدی `PROGRESS.md` با وضعیت واقعی ایجاد کن. توقف به علت محدودیت محیط را با تکمیل‌بودن اشتباه نگیر.

## ۲. زمینه و منابع قطعی پروژه

- شرکت: پخش سایه سمن، ایران؛ محدوده اولیه: تهران.
- مخزن مبنا: https://github.com/microsoft/multi-agent-marketplace
- کاتالوگ معرفی‌شده توسط مالک پروژه: https://catalog.sayesaman.com/
- VTT توسعه، طبق اعلام مالک: `172.20.3.81:30089`.
- VTT عملیاتی، طبق اعلام مالک: `172.20.4.81:30081`.
- پروتکل، مسیر درخواست، احراز هویت، codec، sample rate و قرارداد پیام‌های این دو VTT هنوز تأیید نشده است. هیچ‌کدام را حدس نزن و اتصال موفق ادعا نکن.
- ERP/WMS، انبارها، ناوگان، مشتریان، قیمت، بهای تمام‌شده، سقف اعتبار، ضرایب تبدیل و سیاست تخفیف واقعی هنوز ارائه نشده‌اند.
- اطلاعات عمومی شرکت صرفاً برای معرفی برند است؛ داده عملیاتی باید از خروجی تأییدشده شرکت یا API معتبر بیاید.

### مشاهدات مستقیم کاتالوگ در زمان تنظیم این پرامپت

صفحه یک برنامه Blazor WebAssembly است؛ HTML اولیه فقط پوسته و loading دارد. استخراج با requests از HTML اولیه به معنی استخراج محصولات نیست. در رابط، دسته‌هایی تحت عنوان «برند» دیده شدند؛ از جمله عالیفرد، شیوا، نستله، رکسان و دارا، لاوین گوار آریا، لاوین رژ، ایگل البرز شمال، رامونا سلامت، دشت میوه، شرکت نیک پارس، رز گل، لاوین دشت ایرانیان، دیان، آریا تجارت مکران، پوراطب گسترایرانیان، ایران داروک، روز دارو، جهان صادرات و پارس تیشو. این فهرست مشاهده رابط است؛ از آن فعال‌بودن قرارداد، نمایندگی انحصاری، موجودی یا مجوز فروش همه گروه‌ها نتیجه نگیر. در مرحله اول گروه‌های غذایی تأییدشده را فعال کن؛ سایر گروه‌ها را بدون بررسی وارد سفارش خودکار نکن.

نمونه‌های مشاهده‌شده، برای آزمون importer و جست‌وجوی فارسی؛ در زمان ساخت دوباره با منبع تطبیق بده:

| کد داخلی | عنوان مشاهده‌شده | تعداد نمایش‌داده‌شده در بسته | بارکد نمایش‌داده‌شده |
|---|---|---:|---|
| 100255 | شربت پرتقال سن ایچ بطری 12*780GR | ۱۲ | 6260100600041 |
| 100803 | شربت پرتقال سن ایچ بطری 6*780GR | ۶ | 6260100600041 |
| 100337 | نکتار پرتقال سن ایچ پاکت 36*200CC | ۳۶ | 6260100684515 |
| 100308 | آبميوه سيب سن ایچ پاکت 12*1LIT | ۱۲ | 6260100601147 |
| 101480 | پاستیل اعداد شیبا 160GR*24 | ۲۴ | 6260101405621 |
| 101493 | پاستیل میکس شیبا 160GR*24 | ۲۴ | 6260101405676 |
| 101810 | پاستيل تمرهندی شیبا 36*90GR | ۳۶ | 6260101402613 |
| 100433 | پاستیل تمبر هندی شیبا 32*90GR | ۳۲ | 6260101402613 |

این جدول کامل کاتالوگ نیست. تعداد بسته نیز قبل از استفاده در موجودی عملیاتی باید تأیید شود. بارکد برای چند SKU با بسته‌بندی متفاوت مشترک دیده شده؛ روی barcode قید unique سراسری نگذار و ادغام خودکار نکن. شناسه کسب‌وکار و بسته‌بندی اهمیت دارد. در شربت با عنوان 780GR، فیلد وزن 786 G دیده شد؛ تفاوت معنای وزن خالص/ناخالص یا خطای داده هنوز مشخص نیست. مقدار خام را نگه دار، تعارض را علامت بزن، اصلاح حدسی نکن. مقدار G را به CC تبدیل نکن.

در سایت رسمی شیوا، سایه سمن به‌عنوان شرکت صادرات، فروش و پخش محصولات شیوا معرفی شده است؛ این مشاهده جایگزین master data فعلی شرکت نیست: https://www.shivamfgco.com/shiva1/contact/

## ۳. بررسی و استفاده واقعی از مخزن Microsoft

پیش از توسعه README، LICENSE، TRANSPARENCY، pyprojectها، tests، docs و مسیرهای اصلی را بخوان. commit دقیق استفاده‌شده را pin کن. SHA مشاهده‌شده هنگام تهیه این مشخصات `9a651c7632685e4aeb2956dfe315df0cec6e8a92` بود؛ این را بدون بررسی به‌عنوان آخرین commit معرفی نکن.

نکات مشاهده‌شده که باید در checkout تطبیق بدهی:

- workspace مبتنی بر uv با package در `packages/magentic-marketplace`.
- package دارای Python >=3.11 و وابستگی‌های FastAPI، SQLAlchemy، Pydantic، asyncpg و aiosqlite است.
- CLI با نام `magentic-marketplace`.
- عامل‌های CustomerAgent و BusinessAgent و چرخه step؛ امکانات search، fetch messages، send messages.
- پیام‌های TextMessage، OrderProposal و Payment در پروتکل پژوهشی.
- مدل نمونه دامنه دارای menu_features و amenity_features و قیمت float است؛ برای SKU، پول و موجودی واقعی مناسب نیست.
- compose ریشه مشاهده‌شده فقط PostgreSQL و pgAdmin را بالا می‌آورد؛ نباید آن را compose کامل محصول معرفی کنی.
- TRANSPARENCY صریحاً محیط را پژوهشی و نامناسب برای استقرار تجاری مستقیم توصیف می‌کند؛ داده مصنوعی و ارزیابی انگلیسی آن تضمین رفتار در ایران نیست.

خروجی اولیه: `docs/UPSTREAM_AUDIT.fa.md` شامل SHA، نسخه Python، ساختار، دستورهای واقعاً اجراشده، نتیجه تست‌ها، مجوزها، اجزای قابل‌استفاده، شکاف‌ها و جدول «استفاده مجدد / توسعه / جایگزینی».

از runtime، agent abstractions، پروتکل پیام یا experiment runner هرجا مناسب است واقعاً استفاده کن و این استفاده را با integration test نشان بده. افزودن README یا کپی‌کردن مخزن بدون اتصال اجرایی کافی نیست. یک adapter مشخص برای دامنه سایه سمن بساز. بخش پژوهشی در محیط جدا باقی بماند؛ سرویس سفارش واقعی باید از domain service تراکنشی عبور کند. Payment پژوهشی را به پرداخت واقعی یا تسویه موفق تبدیل نکن.

اگر reuse یک بخش به اطمینان سیستم آسیب می‌زند، دلیل را مستند و آن بخش را جدا کن. simulator و comparison harness می‌توانند upstream را به کار بگیرند، در حالی که transaction core جدید است. LICENSE و attribution را حفظ کن؛ لوگوی مایکروسافت یا ادعای تأیید محصول توسط آن اضافه نکن. در ZIP، کد لازم در commit ثابت یا vendor مجاز همراه patchها موجود باشد؛ submodule خالی قابل‌قبول نیست.

## ۴. محدوده ساخت و سطوح آمادگی

چهار حالت روشن با مرز واقعی پیاده‌سازی کن:

1. **نمایش قطعی / demo:** seed مشخص، داده عملیاتی مصنوعی، fake provider آشکار، بدون کلید خارجی قابل‌اجرا. این حالت را «AI زنده» معرفی نکن.
2. **شبیه‌سازی با مدل واقعی / simulation:** LLM واقعی و ابزارها، اما transactionها در sandbox؛ هزینه و محدودیت provider ثبت شود.
3. **حالت سایه / shadow:** داده واقعی فقط خواندنی؛ پیشنهاد تولید می‌شود ولی سفارش و پیام بیرونی ثبت/ارسال نمی‌شود.
4. **پایلوت کنترل‌شده / pilot:** دامنه مشتری، کالا، مبلغ و اختیار محدود؛ اتصال رسمی، تأیید لازم، ثبت audit و kill switch.

Production یک برچسب تنظیماتی برای پنهان‌کردن کمبودها نیست. بدون قیمت/موجودی معتبر، قرارداد اتصال، آزمون staging و پذیرش مسئول شرکت، آماده production اعلام نکن. demo و pilot باید در datastore، credentials و مرز شبکه جدا باشند؛ تغییر فلگ UI نباید مجوز نوشتن واقعی بدهد.

موارد ضروری نسخه تحویلی: کاتالوگ، ورود داده، مشتری، درخواست خرید، agent run، گروه‌سازی، مذاکره محدود، quote، تأیید، رزرو اتمیک، سفارش مستقل، برنامه مسیر، اختلال و replanning، رویدادهای زنده، مقایسه baseline، گزارش و بسته نصب. VTT و نقشه بیرونی به‌صورت adapter قابل‌تست و اتصال طبق قرارداد؛ قطع آن‌ها کل محصول را از کار نیندازد.

موارد توسعه بعدی که نباید مانع تکمیل هسته شوند: چند شرکت پخش مستقل، A2A بین‌سازمانی، تأمین مالی، پرداخت واقعی، پیش‌بینی تقاضای پیشرفته، تشخیص قفسه، یادگیری آنلاین سیاست قیمت. برای آن‌ها seam و backlog بده، نه ادعای پیاده‌سازی ساختگی.

## ۵. تجربه کاربر و طراحی بصری

محصول یک workspace سازمانی باشد: منوی راست، نوار وضعیت اتصال/حالت در بالا، مرکز عملیات و صفحات وظیفه‌محور. از شلوغی رنگی، انیمیشن ربات و متن‌های تبلیغاتی مبهم دوری کن. در پوسته عمومی کاتالوگ رنگ‌های خاکستری و زرد دیده شد؛ تا دریافت brand guideline، این‌ها فقط جهت پیشنهادی‌اند. لوگوی رسمی را از منبع مجاز تهیه کن؛ لوگوی اختراعی را لوگوی شرکت معرفی نکن.

- فارسی‌سازی کامل با `lang=fa` و `dir=rtl`؛ فونت فارسی دارای مجوز و میزبانی محلی، مانند Vazirmatn پس از بررسی مجوز.
- نمایش تاریخ شمسی، ذخیره UTC، تفسیر «فردا» با Asia/Tehran و بازنمایی تاریخ دقیق قبل از تأیید.
- ورودی رقم فارسی/عربی/لاتین؛ یکسان‌سازی ی/ک و نیم‌فاصله برای جست‌وجو بدون تغییر مقدار خام.
- مبلغ با واحد واضح ریال یا تومان؛ تبدیل دقیق، بدون حدس واحد. بارکد و شناسه قابل‌کپی با نمایش مناسب LTR.
- طراحی پاسخ‌گو برای دسکتاپ مدیر و موبایل مغازه‌دار/ویزیتور، صفحه‌کلید، focus، contrast و کاهش حرکت.
- skeleton، empty، stale، loading، retry، unauthorized، no-provider و error state واقعی.
- فیلترها در URL و pagination سمت سرور؛ جدول‌های بزرگ virtualized در صورت نیاز.
- هر عدد داشبورد منبع، زمان و دامنه داده داشته باشد؛ صفر با «ناموجود» یکی نیست.
- گزارش و export به دسترسی همان نقش محدود؛ CSV formula injection مهار شود.
- دکمه نمایشی بدون کارکرد، اعلان موفقیت جعلی و KPI تصادفی ممنوع.

صفحات لازم:

1. **مرکز عملیات:** سفارش‌های معطل، گروه‌های در حال تشکیل، تأییدهای لازم، وضعیت انبار و مسیر، هزینه AI و هشدارها.
2. **نقشه تهران:** مشتری/انبار/خودرو، گروه سفارش، مسیر قبل/بعد، رنگ وضعیت و فیلتر شعبه/روز/برند؛ نمایش جدول جایگزین در قطع نقشه.
3. **کاتالوگ:** جست‌وجوی نام/کد/بارکد، عکس، بسته‌بندی، تفاوت عدد و کارتن، منشأ داده و تعارض‌ها. قیمت فقط از pricebook معتبر.
4. **پنل مشتری:** نیاز متنی/صوتی، بودجه، زمان، جایگزین مجاز، پیشنهادها و تأیید نسخه مشخص سفارش.
5. **میز معامله:** طرف‌ها، پیشنهاد و counteroffer، محدودیت‌ها، سهم صرفه‌جویی، علت رد و وضعیت اعتبار quote.
6. **مرکز عامل‌ها:** نقش، پرونده فعال، اقدام ساختاریافته، ابزار، نتیجه، توقف، خطا، هزینه؛ خلاصه مستند تصمیم، نه نمایش chain-of-thought خصوصی مدل.
7. **انبار و تخصیص:** on-hand، reserved، available، batch، expiry، قرنطینه و تعارض sync.
8. **سفارش و تحویل:** چرخه وضعیت، اقلام، رزروها، مرجع ERP، برنامه سفر، کسری/مرجوعی و تاریخچه.
9. **آزمایشگاه سناریو:** اجرای baselineها، اختلال، replay و گزارش مقایسه با منشأ داده.
10. **تنظیمات و سلامت:** providerها، قوانین، کاربران، سطح اختیار، import و diagnostics بدون نمایش secret.

## ۶. معماری پیشنهادی و حدود پیچیدگی

از modular monolith با worker مجزا شروع کن؛ تعداد زیاد microservice یا چند framework ایجنتی موازی نساز. تصمیم نهایی را با upstream audit سازگار کن.

- frontend: React + TypeScript، ترجیحاً Next.js با نسخه پایدار و lockfile؛ RTL component system و لایه API typed.
- backend: Python سازگار با upstream، FastAPI، Pydantic، SQLAlchemy و Alembic.
- دیتابیس مرجع: PostgreSQL؛ PostGIS اگر برای spatial query واقعاً استفاده می‌شود.
- worker و queue برای اجرای ایجنت/بهینه‌سازی/import؛ Redis و یک راهکار صف مشخص در صورت نیاز. queue وضعیت مالی/موجودی مرجع نیست.
- رویدادهای UI با SSE دارای cursor/reconnect؛ WebSocket فقط برای مورد لازم مانند voice streaming.
- بهینه‌سازی با OR-Tools یا حل‌کننده متن‌باز مناسب؛ مدل زبانی حل‌کننده دقیق ظرفیت/مبلغ نیست.
- object storage محلی یا S3-compatible برای تصاویر و exportها با دسترسی کنترل‌شده.
- reverse proxy با TLS در محیط سازمان؛ runtime با service account کم‌اختیار.
- logging ساختاریافته، metrics و trace با correlation_id؛ پیچیدگی monitoring متناسب با پایلوت.

ساختار پیشنهادی قابل‌تطبیق:

```text
apps/web/
services/api/
services/worker/
packages/domain/
packages/agents/
packages/integrations/
packages/simulation/
vendor/multi-agent-marketplace/
data/catalog_snapshots/
data/demo/
tests/{unit,integration,e2e,contracts,load}/
infra/
scripts/
docs/
```

Domain logic در UI، prompt یا route handler دفن نشود. provider، pricebook، inventory و routing interface قابل‌تعویض باشند. نسخه‌ها pin و migration از روز اول وجود داشته باشد.

## ۷. ورود و حاکمیت داده کاتالوگ

ترتیب ترجیح: export رسمی/API مستند شرکت، سپس داده عمومی مشاهده‌شده در برنامه، سپس browser extraction مجاز. endpoint حدسی یا hidden auth bypass نساز. robots و شرایط دسترسی و نرخ درخواست را رعایت کن. اگر ساختار شبکه و API را بررسی می‌کنی فقط درخواست‌های عمومی همان صفحه و دامنه مجاز را مبنا قرار بده.

Importer باید resumable، محدود به دامنه‌های مجاز و قابل‌گزارش باشد. raw snapshot، زمان دریافت، URL، hash، parser version، field provenance و coverage ذخیره کند. اگر فقط عالیفرد و شیوا استخراج شدند، عنوان «کاتالوگ کامل» نده. فیلتر غذایی فعال و گزارش گروه‌های خارج از scope داشته باشد.

فیلدهای مستقل: catalog_group، manufacturer، brand، product_family، SKU، packaging، flavor، net_content، declared_weight، gross_shipping_weight. هیچ‌کدام را از دیگری بدون قاعده تأییدشده نتیجه نگیر. کد و بارکد string باشند. تصاویر با مجوز و منشأ محلی cache شوند؛ نبود عکس مانع سفارش نباشد.

قیمت، موجودی و انقضا از کاتالوگ ظاهری قابل‌استنتاج نیستند. فیلد ناموجود null و وضعیت completeness مشخص باشد؛ برای live از استفاده رکورد ناقص جلوگیری کن. حداقل سفارش، تعداد در کارتن، اشانتیون، کالای فعال و امکان فروش تکی از master data معتبر بیاید.

CSV/XLSX import wizard با template، preview، mapping، validation، row-level errors، dry-run، commit و rollback منطقی ارائه کن. جایگزینی داده‌های سفارش‌های گذشته با داده جدید ممنوع؛ snapshot قیمت/نام/بسته‌بندی زمان سفارش حفظ شود. sync منبع نباید اصلاح دستی تأییدشده را بی‌صدا overwrite کند.

## ۸. مدل داده و واحدهای دقیق

حداقل entityها: Organization، Branch، User، Role، Store، AgentMandate، Warehouse، Vehicle، ProductFamily، SKU، PackagingUnit، BarcodeAlias، PriceBookVersion، InventoryBatch، StockMovement، StockReservation، PurchaseIntent، Coalition، CoalitionMembership، NegotiationSession، ProposalVersion، Approval، Order، OrderLine، Fulfillment، RoutePlan، RouteStop، DeliveryEvent، ReturnRequest، IntegrationOutbox، AuditEvent، AgentRun، ToolInvocation، ModelUsage، Scenario، ExperimentRun، ImportJob و IntegrationConnection.

روی همه entityهای عملیاتی scope سازمان/شعبه، ID، version، timestamps و actor درست تعریف کن. UUID داخلی مستقل از کد شرکت داشته باش. currency و money با integer ریال و Decimal برای محاسبات میانی؛ float برای پول ممنوع. مقدار منفی، overflow و rounding صریحاً کنترل شود. تومان نمایشی با تبدیل دقیق به ریال است، نه ارز متفاوت خاموش.

واحد پایه موجودی و conversion در هر SKU تأیید شود. کارتن ۶تایی و ۱۲تایی، بسته و عدد، وزن گرم/کیلو و حجم میلی‌لیتر/لیتر مستقل باشند. fractional carton فقط اگر سیاست شرکت اجازه دهد؛ گردکردن بی‌اجازه ممنوع. وزن حمل از وزن محصول تنها به‌صورت فرض برچسب‌خورده در demo ساخته شود؛ برای live نیاز به داده معتبر دارد.

source_of_truth هر فیلد مشخص باشد: کاتالوگ برای معرفی، ERP/WMS برای موجودی/قیمت/اعتبار طبق قرارداد، runtime برای مذاکره، domain ledger برای رزروهای محلی و هماهنگی. تا تأیید نوشتن در ERP، سفارش «ثبت قطعی ERP» محسوب نشود.

## ۹. طراحی ایجنت‌ها و ابزارها

هر ایجنت goal، principal، allowed_tools، memory scope، budget، deadline، max_steps و وضعیت پایدار داشته باشد. فعال‌شدن رویدادمحور باشد؛ برای هر مشتری process بی‌نهایت polling نساز.

نقش‌ها:

- **نماینده خرید:** نیاز، بودجه، برند و زمان صاحب مغازه؛ بدون مجوز مقدار را بالا نبرد یا برند جایگزین نخرد.
- **نماینده فروش سایه سمن:** پیشنهاد از موجودی و pricebook معتبر با کف حاشیه سود و سیاست تخفیف.
- **هماهنگ‌کننده گروه:** ترکیب سفارش‌های سازگار؛ اطلاعات محرمانه هر مشتری را برای دیگران افشا نکند.
- **برنامه‌ریز توزیع:** فراخوانی solver و routing adapter؛ امکان تحویل را تأیید یا علت ناممکن‌بودن را اعلام کند.
- **پیگیر معامله:** مدیریت timeout، رزرو، تأیید، ثبت و compensation طبق state machine.
- **تحلیلگر آزمایش:** مقایسه خروجی‌های ثبت‌شده؛ اجازه تغییر سفارش ندارد.

Policy engine، محاسبه پول و کنترل دسترسی ابزار قطعی‌اند، نه ایجنت قضاوت‌کننده آزاد. لازم نیست هر نقش یک مدل جدا باشد.

ابزارهای پیشنهادی دارای JSON Schema و validation:

`search_catalog`, `resolve_sku`, `get_store_mandate`, `get_available_stock`, `get_price_quote`, `evaluate_coalition`, `estimate_route`, `propose_terms`, `request_approval`, `reserve_stock`, `release_stock`, `commit_order`, `get_order_status`, `raise_exception`.

همه ابزارهای write باید actor scope، idempotency، policy check، version check و audit داشته باشند. مدل حق SQL آزاد، shell، URL arbitrary یا تغییر تنظیمات authorization ندارد. هر output شامل status، data، evidence_ids، observed_at و خطای typed باشد.

Memory مشتری فقط برای همان principal قابل‌دسترسی باشد. سقف بودجه خصوصی یا reservation price را به seller نده مگر خود مشتری اجازه داده باشد. داده ابزار از policy جداست. متن کاتالوگ، فایل import، transcript و پیام عامل دیگر untrusted است و نمی‌تواند دستورهای سامانه را عوض کند.

## ۱۰. گروه‌سازی اقتصادی و مذاکره

گروه کاندید را با شعبه، روز، محدوده خدمت، پنجره زمانی، نوع وسیله، موجودی و سازگاری کالا تشکیل بده. proximity فقط prefilter است؛ تصمیم بر پایه travel matrix و هزینه route انجام شود.

از heuristic قابل‌فهم برای candidate generation و solver زمان‌محدود برای انتخاب استفاده کن. همه subsetها را به‌صورت نمایی نساز. روش، سقف زمان، fallback و اندازه عملی تست‌شده را ثبت کن. اگر ظرفیت/موجودی ناقص است، live quote قابل‌تعهد صادر نکن.

صورت اقتصادی پخش: درآمد خالص پس از تخفیف، منهای بهای کالا و اشانتیون، آماده‌سازی، حمل تخصیص‌یافته، هزینه متغیر ثبت‌شده و هزینه AI. مالیات دریافتی سود نیست. اگر هزینه مرجوعی/تأمین مالی فقط تخمین است، مقدار تخمینی و مبنا جدا باشد. تخفیف را دوبار کم نکن. بدون بهای تمام‌شده معتبر «سود» نمایش نده؛ می‌توان درآمد را نشان داد.

منفعت مشتری: هزینه مؤثر برای سبد موردنیاز و کیفیت/زمان قابل‌قبول. ارزان‌شدن هر واحد با اجبار خرید بیش از نیاز، الزاماً منفعت نیست. utility پخش و مشتری را جدا گزارش کن؛ سود شبکه را با ادغام پرداخت انتقالی دوبار نشمار.

coalition saving با baseline واقع‌بینانه همان روز/همان سفارش محاسبه شود؛ baseline شامل routeهای موجود شرکت باشد، نه فرض ساختگی «یک خودرو برای هر مغازه». روش تقسیم منفعت ثابت، قابل‌توضیح و نسخه‌دار باشد. بودجه تخفیف محدود و سهم پخش و مشتری روشن؛ سهم مجموع دقیقاً با saving سازگار باشد. محاسبه شاپلی را فقط در صورت نیاز و امکان مقیاس اضافه کن، نه برای نمایش پیچیدگی.

پیشنهاد باید proposal_id، version، line items، SKU، unit، quantities، prices، discount، tax policy reference، delivery window، expiry، stock snapshot، terms_hash و شرایط مشروط داشته باشد. پذیرش به همان version/hash مربوط است. تغییر مبلغ، کالا یا زمان، تأیید قبلی را باطل می‌کند.

max_rounds، max_duration، min_improvement و no-progress detection تنظیم شود. در شکست مذاکره، نتیجه بدون توافق معتبر است. مدل حق وعده تضمینی ETA یا تخفیف خارج از سیاست ندارد. برای پیشنهادهای غیرقطعی، رزرو موجودی ادعا نشود.

## ۱۱. چرخه معامله، هم‌زمانی و جلوگیری از فروش دوباره

چرخه پیشنهادی intent:

`draft → validated → matching → negotiating → awaiting_approval → reserving → confirmed → dispatched → delivered`

شاخه‌های `expired`, `rejected`, `cancelled`, `partially_fulfilled`, `failed`, `needs_review` را با transition مجاز تعریف کن. invoice/payment state و fulfillment state جدا باشند. «accept» معادل «paid» نیست.

برای رزرو موجودی از transaction دیتابیس و row lock یا atomic conditional update استفاده کن. invariant: available هرگز منفی نشود و مجموع رزرو فعال از موجودی قابل‌فروش بیشتر نشود. رزرو TTL، release job، تمدید محدود و reconciliation دارد. قیمت و موجودی درست پیش از commit بازبینی شوند.

تأیید گروه سفارش یک مسئله چندطرفه است: پیش‌شرط‌ها را ثبت، reservationها را اخذ و سپس commit کن؛ برای شکست یکی از اعضا compensation یا گروه جدید بساز. تعهد قطعی سایر مشتریان را خودسرانه تغییر نده. برای ERP خارجی distributed transaction فرض نکن؛ transactional outbox، idempotency key، reconciliation و saga/compensation لازم است.

retries با backoff و سقف؛ dead-letter و امکان بررسی انسانی. تحویل queue at-least-once است، پس side effect باید idempotent باشد؛ ادعای exactly-once سراسری نکن. پس از restart از checkpoint معتبر ادامه بده. دریافت duplicate event، قبول quote منقضی و رقابت workerها تست شود.

تمام تغییرهای stock movement و سفارش actor و علت داشته باشند. مرجوعی کالای غذایی پس از ثبت درخواست، تا تأیید کیفیت وارد موجودی قابل‌فروش نشود. FEFO با سیاست حداقل عمر باقی‌مانده مشتری، قرنطینه و batch traceability رعایت شود.

## ۱۲. نقشه تهران و برنامه توزیع

مرکز نمایش اولیه تهران، نه مختصات فرضی انبار واقعی. مشتری و انبار demo با نام واضح «آزمایشی» ساخته شوند؛ آدرس و GPS واقعی شرکت از اینترنت حدس زده نشود. Lat/Lon و ترتیب آن‌ها با تست کنترل شود. اگر مختصات مشتری وارد نیست، برای live geocode/تأیید پین لازم است.

نقشه نمایش و موتور مسیریابی دو interface جدا باشند. MapLibre یا Leaflet برای نمایش قابل‌استفاده است؛ تأمین tile، glyph، فونت فارسی، attribution و قرارداد provider مستقل بررسی شود. route geometry باید از routing service بیاید. خط مستقیم با برچسب «تقریبی» فقط demo است؛ آن را مسیر خیابانی یا ترافیک زنده ننام.

Provider قابل‌تعویض: سرویس ایرانی مستند مانند نشان در صورت فراهم‌بودن کلید و قرارداد؛ یا OSRM/Valhalla self-hosted با داده معتبر. سازگاری ایران، محدودیت نرخ و سقف هزینه را بررسی کن. از private endpoint نقشه‌های مصرف‌کننده یا کلید دزدیده‌شده استفاده نکن. دانلود انبوه tile عمومی یا cache خلاف مجوز ممنوع.

قیدها: ظرفیت وزن/حجم/کارتن، service time، بازه زمانی، شیفت، نقطه شروع/پایان، توقف‌ها و استراحت، برگشت خودرو، کالای ناسازگار/زنجیره سرد در صورت وجود، چند انبار و هزینه انتقال. محدودیت تردد تهران و تعطیلات فقط از تنظیمات تأییدشده وارد شوند؛ قانون و ترافیک را حدس نزن.

travel matrix دارای provider، timestamp، traffic_mode و TTL باشد. هزینه اضافی گروه نسبت به route موجود محاسبه شود. replanning توقف‌های انجام‌شده و تعهدهای ثابت را حفظ کند. حداکثر زمان حل و fallback همراه علت infeasible داشته باش. در نبود map provider، جدول مسیر و هزینه‌های دارای منشأ همچنان کار کند. یک fixture محلی دارای مجوز برای demo آماده کن.

## ۱۳. اتصال به VTT اختصاصی شرکت

سرویس آماده مالک پروژه را استفاده کن؛ بی‌دلیل STT تازه نساز. ابتدا قرارداد از مستندات یا نمونه client تأییدشده کشف شود. host:port به‌تنهایی HTTP، WebSocket یا path را مشخص نمی‌کند. آدرس‌های 172.20 خصوصی‌اند و ممکن است فقط از شبکه شرکت قابل‌دسترسی باشند؛ عدم دسترسی محیط توسعه را با خرابی سرویس اشتباه نگیر.

در محیط مجاز ابتدا develop را با تست محدود و غیرمخرب بررسی کن. prod پیش‌فرض تست خودکار نباشد. شبکه شرکت را scan نکن. اگر دسترسی یا قرارداد موجود نیست، adapter، mock مبتنی بر قرارداد پیشنهادی و راهنمای integration بساز و وضعیت را «تأییدنشده» نشان بده؛ اتصال ساخته‌شده تلقی نکن.

پیکربندی اولیه فقط به‌صورت داده غیرمحرمانه سمت سرور:

```dotenv
VTT_DEV_HOST=172.20.3.81
VTT_DEV_PORT=30089
VTT_PROD_HOST=172.20.4.81
VTT_PROD_PORT=30081
VTT_TARGET=develop
VTT_PROTOCOL=
VTT_PATH=
VTT_AUTH_MODE=
VTT_SAMPLE_RATE=
VTT_ENCODING=
VTT_CONNECT_TIMEOUT_SECONDS=5
VTT_SESSION_MAX_SECONDS=120
VTT_ENABLED=false
```

مقادیر timeout و سقف طول، پیش‌فرض پیشنهادی قابل‌تغییرند، نه مشخصات سرویس. کلید، token و endpoint کامل فقط در secrets/env سرور. آدرس خصوصی در bundle مرورگر قرار نگیرد. UI به gateway هم‌مبدأ HTTPS/WSS متصل شود؛ gateway فقط به مقصد allowlisted داخلی متصل شود. مجوز میکروفون فقط با اقدام کاربر و secure context؛ mixed-content و محدودیت مرورگر لحاظ شود.

UI: شروع/توقف ضبط، نشانگر واضح ضبط، partial transcript قابل‌جایگزینی با final، ویرایش متن، retry و fallback تایپ. reconnect نباید متن را دوبار اضافه کند. codec و sample rate مطابق قرارداد واقعی؛ MediaRecorder WebM/Opus را بدون تأیید به سرویس PCM نفرست. تست ترتیب chunk، finalization، قطع اتصال، silence و خطای auth لازم است.

پس از transcript، intent extraction ساختاریافته: نام/کد کالا، تعداد، واحد، بودجه، زمان و محدودیت برند. «دو کارتن آبمیوه پرتقال» اگر چند SKU سازگار داشت نیاز به رفع ابهام دارد. «پنج تومن» واحد/مقدار مبهم است. confidence عددی را از خودت نساز. قبل از سفارش، کارت بازبینی با SKU/عکس/تعداد و تعداد واحد پایه/قیمت/زمان نشان بده. صوت به‌تنهایی اجازه خرید نامحدود نیست. ذخیره صوت خام پیش‌فرض خاموش؛ retention و رضایت قابل‌تنظیم.

## ۱۴. ERP، WMS و اتصال‌های سازمانی

interfaceهای CatalogProvider، PriceProvider، InventoryProvider، CreditProvider، OrderSink، DeliveryProvider و IdentityProvider تعریف کن. سه پیاده‌سازی مشخص: in-memory یا DB demo، file import/export، adapter واقعی طبق قرارداد شرکت. adapter بدون credentials به‌وضوح disconnected باشد.

برای ERP مستند شود: شناسه سفارش بیرونی، mapping مشتری/SKU/واحد، pricebook، tax، روش پرداخت، timestamp و version، timeout، retry، webhook auth و reconciliation. در حالت file integration خروجی پیش‌فاکتور یا درخواست سفارش بده؛ ادعای sync زنده نکن.

اعتبار مشتری از سامانه/سیاست مصوب خوانده شود. LLM اعتبار مالی را خودش اعطا نکند. سقف و مانده stale باعث بازبینی شود. ارسال پیام واقعی، ثبت سفارش در ERP، پرداخت و dispatch فقط در محدوده عملیاتی فعال و اختیار مصوب. این مرحله ساخت پروژه مجوز ارسال پیام به مشتریان واقعی یا تغییر prod نیست.

## ۱۵. مدل زبانی و ارزیابی فارسی

یک LLMGateway قابل‌تعویض با مدل/provider ID، base URL، credentials سمت سرور و timeout بساز. امکان مدل local/self-hosted یا API سازگار با شرایط استقرار. نسخه مدل pin شود؛ مدل خاصی را بدون benchmark بهترین معرفی نکن. از wrapper upstream هرجا مناسب است استفاده کن؛ چند framework تکراری نصب نکن.

خروجی structured و validate‌شده؛ invalid JSON، ابزار ناموجود، پارامتر غلط و پاسخ بدون evidence کنترل شود. repair محدود و سپس fallback انسانی/قطعی. budget per-run، concurrency limit، token/cost metrics، circuit breaker، cancellation و max retries. هزینه بدون جدول قیمت معتبر provider «نامشخص» باشد؛ تعداد token همچنان قابل‌گزارش است.

حداقل مجموعه ارزیابی فارسی شامل نام‌های سن ایچ/سن‌ایچ، شیبا/شیوا با mapping تأییدشده، غلط املایی، واحد بسته و کارتن، رقم فارسی، اصلاح جمله، نفی، تغییر نظر، بودجه مبهم و تاریخ نسبی. ساخت داده آزمایشی برچسب synthetic؛ برای ادعای دقت واقعی نمونه ناشناس و تأییدشده شرکت لازم است.

مدل برای intent، توضیح، انتخاب ابزار و مذاکره در فضای مجاز؛ arithmetic، قواعد پولی، موجودی و route در سرویس قطعی. حافظه و cached responseهای حساس بین مشتری‌ها مشترک نباشند. replay دقیق از eventهای ثبت‌شده است؛ تکرار LLM با temperature صفر تضمین یکسان‌بودن نمی‌دهد.

## ۱۶. دسترسی، اختیار و audit

نقش‌های مدیر سامانه، مدیر هلدینگ، مدیر شعبه، سرپرست فروش، ویزیتور، برنامه‌ریز توزیع، مسئول انبار، مشتری و مشاهده‌گر دمو. ماتریس دسترسی در API و object scope enforce شود، نه صرفاً hidden menu. مالی/بهای تمام‌شده برای مشتری قابل‌مشاهده نباشد. مشتری فقط داده خودش را ببیند.

سه سطح اختیار: پیشنهاد، اجرا پس از تأیید، اجرای محدود با mandate. mandate شامل principal، کالا/گروه مجاز، مبلغ هر سفارش و روزانه، تعداد، زمان انقضا، جایگزینی، روش پرداخت و محدوده تحویل باشد. revocation فوری روی tool callهای بعدی اثر کند. تغییر مبلغ یا شروط، approval جدید می‌خواهد.

ورود امن با امکان OIDC سازمانی و local auth امن برای demo/pilot؛ password پیش‌فرض production وجود نداشته باشد. session، CSRF طبق روش auth، CORS محدود، rate limiting، secret redaction، encryption in transit، backup محافظت‌شده و عدم exposure دیتابیس/pgAdmin به اینترنت.

Catalog URL fetch و تصویر import باید SSRF protections داشته باشند. دسترسی عمدی gateway به VTT خصوصی با allowlist اختصاصی و مستقل از URLهای کاربر مجاز شود؛ allowlist عمومی private subnet ایجاد نکن. ورود فایل حجم/نوع/محتوا را validate کند؛ XSS و formula injection و path traversal مهار شود.

Audit شامل actor/principal، action، resource/version، before/after مناسب، evidence، policy_version، model/prompt version، نتیجه، زمان و correlation_id است. نگهداری داده حساس و retention مشخص باشد. خلاصه تصمیم قابل‌ممیزی نشان بده، نه زنجیره فکر خصوصی مدل. kill switch اجرای write عامل‌ها را متوقف کند ولی امکان مشاهده و رسیدگی به سفارش‌های موجود حفظ شود.

## ۱۷. API و قرارداد رویداد

OpenAPI نسخه‌دار و API `/api/v1` با خطاهای typed. مسیرهای محصول پیشنهادی‌اند، نه endpoint کشف‌شده upstream:

```text
GET  /catalog/products
POST /catalog/imports
GET  /catalog/imports/{id}
POST /purchase-intents
POST /purchase-intents/{id}/validate
POST /agent-runs
GET  /agent-runs/{id}
POST /agent-runs/{id}/cancel
POST /coalitions/evaluate
GET  /negotiations/{id}
POST /proposals/{id}/accept
POST /proposals/{id}/reject
POST /approvals/{id}/decide
GET  /orders/{id}
POST /routes/plan
POST /scenarios/{id}/runs
GET  /events
GET  /integrations/health
POST /voice/sessions
GET  /health/live
GET  /health/ready
```

accept/approve/commit مجوز و idempotency و expected_version لازم دارند. exportها asynchronous و scoped باشند. frontend از schema مشترک/تولیدشده استفاده کند. خطای فارسی همراه error_code ثابت؛ اطلاعات داخلی stack trace در پاسخ عمومی ممنوع.

event envelope: event_id، event_type، schema_version، aggregate_id، aggregate_version، occurred_at، tenant_id، branch_id، correlation_id، causation_id، mode و payload. رویدادهای نمونه: IntentValidated، CoalitionProposed، ProposalIssued، ApprovalRequested، StockReserved، OrderConfirmed، RouteReplanned، DeliveryRecorded، IntegrationFailed. SSE با cursor و replay محدود و scope authorization؛ reconnect باعث duplicate UI یا عملیات نشود.

## ۱۸. سناریوهای دمو برای ارائه هلدینگ

seed اولیه پیشنهادی: ۲۰ فروشگاه مصنوعی تهران، دو انبار مصنوعی، سه خودرو مصنوعی و ۳۰ SKU تأییدشده از کاتالوگ در صورت دسترسی. اگر ۳۰ SKU واقعی استخراج نشد، تعداد واقعی را اعلام و fixture ساختگی را جدا برچسب بزن؛ کد ساختگی را کد شرکت معرفی نکن. قیمت، cost، موجودی، مشتری، مختصات و سفارش demo با namespace و برچسب مصنوعی مستقل باشند.

سناریوها قابل reset و دارای expected outcomes باشند:

1. **نیاز فارسی تا سفارش:** متن یا صوت، رفع ابهام SKU، پیشنهاد، تأیید و ثبت در demo ledger.
2. **گروه خرید هماهنگ:** چند سفارش کوچک با زمان سازگار، صرفه‌جویی محاسبه‌شده، فاکتور مستقل.
3. **انصراف عضو پیش از commit:** re-evaluate و شرایط جدید؛ approval قبلی برای تغییرات معتبر نماند.
4. **خروج خودرو از سرویس:** حفظ توقف‌های انجام‌شده، replanning و اعلام سفارش‌های غیرقابل‌تحویل.
5. **رقابت بر سر آخرین موجودی:** دو پذیرش هم‌زمان و جلوگیری از oversell.
6. **quote منقضی یا قیمت تازه:** جلوگیری از commit نسخه قدیمی و ارائه پیشنهاد جدید.
7. **قطع VTT/مدل/نقشه:** graceful degradation با خطای واقعی و بدون موفقیت نمایشی.
8. **SKU با بارکد مشترک:** انتخاب بسته صحیح و جلوگیری از ادغام ۶تایی/۱۲تایی.
9. **عدم صرفه اقتصادی:** رد تشکیل گروه؛ سیستم برای همه ورودی‌ها خروجی مثبت نسازد.
10. **مجوز ناکافی:** ایجنت درخواست فراتر از mandate را متوقف و برای بررسی ارجاع دهد.

Presentation mode با کنترل شروع/توقف/گام‌به‌گام/بازنشانی، بزرگ‌نمایی قابل‌خواندن، timeline و توضیح کوتاه فارسی. شبیه‌سازی ساعت و replay از live مشخص باشد. اسکریپت ارائه ۵ تا ۷ دقیقه‌ای و راهنمای سؤال‌های مدیران بنویس. هیچ درصد صرفه‌جویی تضمینی یا KPI ازپیش‌ساخته به‌عنوان نتیجه واقعی نشان نده.

## ۱۹. مقایسه علمی و اقتصادی

سه baseline روی dataset و constraints یکسان:

A. سفارش‌گیری با قواعد ثابت و برنامه مسیر معتبر موجود؛
B. گروه‌سازی/مسیریابی با optimizer بدون مذاکره LLM؛
C. گروه‌سازی، مذاکره محدود و replanning ایجنتی.

قیمت، cost، تقاضا، ناوگان، افق زمانی و داده قابل‌مشاهده بین روش‌ها یکسان باشد. از آینده در تصمیم‌های گذشته استفاده نکن. هزینه LLM و زمان محاسبه در C منظور شود. چند seed و چند شدت اختلال گزارش شود؛ نتیجه منفی یا بدون برتری را پنهان نکن. معیار جلوگیری از ادعای کاذب: داده synthetic فقط امکان‌سنجی فنی است، نه اثبات ROI واقعی.

معیارها با تعریف دقیق: contribution margin، هزینه تحویل هر سفارش، fill rate مقدار/سفارش با مخرج مشخص، on-time rate، distance، vehicle utilization، acceptance rate، نیاز به دخالت انسانی، زمان توافق، هزینه AI، نقض قید، مقدار سفارش لغوشده، منفعت مشتری نسبت به baseline و کیفیت توزیع این منفعت. baseline ناممکن برای یک مشتری باید «خدمت‌دریافت‌نکرده» گزارش شود؛ صرفه‌جویی نسبت به بی‌نهایت نساز.

گزارش ماشین‌خوان JSON/CSV و گزارش فارسی با بازه زمانی، dataset hash، config hash، نسخه مدل، seed، assumptions و limitations. بخش «آیا AI ارزش افزوده داشت؟» صریح و بدون نتیجه ازپیش‌تعیین‌شده باشد.

## ۲۰. آزمون‌های اجباری و معیار پذیرش

آزمون‌ها باید خطرهای واقعی کسب‌وکار را پوشش دهند:

- پول: ریال/تومان، rounding، تخفیف و اشانتیون، عدم استفاده float و جمع دقیق.
- واحد: کارتن ۶/۱۲، بسته ۳۲/۳۶، عدم تبدیل G به CC، بارکد تکراری و کد مستقل.
- import: idempotency، رکورد ناقص، conflict، داده مخرب، resume و coverage.
- authorization: دسترسی متقاطع مشتری/شعبه/سازمان، جلوگیری از افشای cost و بودجه خصوصی.
- transaction: رزرو هم‌زمان، stock expiry، duplicate accept، rollback، quote version mismatch و race پس از revocation.
- worker: crash/restart، retry، outbox duplicate و partial failure ERP.
- agent: invalid output، ابزار نامعتبر، prompt injection در transcript و catalog، step/cost limit، توقف و نبود provider.
- routing: ظرفیت، پنجره زمانی، service time، مسیر ناممکن، داده stale و قفل توقف انجام‌شده.
- voice: partial/final، encoding mismatch، قطع اتصال و عدم سفارش بدون review/mandate معتبر.
- E2E فارسی: login → intent → پیشنهاد → approval → سفارش → route → تحویل demo؛ صفحه موبایل و RTL screenshot QA.
- دسترس‌پذیری و browser errors: focus، keyboard، contrast، ترجمه خطا، نبود uncaught exception.

Load test اولیه روی ۱۰۰۰ مشتری ذخیره‌شده، ۱۰۰ intent و حداکثر ۲۰ run هم‌زمان به‌عنوان هدف پیشنهادی، نه ادعای ظرفیت اثبات‌شده. تست demo و live-provider جدا؛ بدون مجوز تست بار روی VTT prod یا API شرکت انجام نده. منابع CPU/RAM، dataset، نرخ، p50/p95 و errors را گزارش کن. هدف پیشنهادی APIهای معمول بدون مدل/solver: p95 زیر ۵۰۰ms روی محیط ثبت‌شده؛ اگر نرسید علت را گزارش کن، نتیجه نساز.

Gate تحویل: نصب پاک قابل‌تکرار، تمام مسیر هسته بدون TODO، migration، تست invariants، تست RBAC، demo صادقانه، لاگ/metric، backup/restore آزمایش‌شده و ZIP قابل‌استخراج. Gate پایلوت واقعی علاوه بر این: قرارداد ERP/VTT/map، data quality تأییدشده، security review و آموزش مسئول عملیات. test skipped به معنی passed نیست.

## ۲۱. نصب، اجرا و شرایط شبکه ایران

Docker Compose کامل برای web، api، worker، PostgreSQL و سرویس‌های واقعاً لازم بساز. healthcheck و dependency readiness واقعی؛ migration job مشخص؛ restart امن؛ volumeهای پایدار. DB و admin ابزارها default روی اینترنت publish نشوند. compose demo با تنظیمات production اشتراک ناامن نداشته باشد.

Bootstrap برای Linux و Windows PowerShell یا مسیر روشن Docker Desktop/WSL2؛ preflight شامل پورت، Docker، فضای دیسک، RAM و دسترسی provider. نسخه حداقلی Docker و runtime مستند. دستور یک‌مرحله‌ای demo بعد از نصب پیش‌نیازها و آماده‌شدن imageها فراهم کن. برای نصب آنلاین نیاز network را صریح بگو؛ ZIP سورس به معنی نصب air-gapped نیست.

font، assetهای ضروری و وابستگی‌های UI از CDN خارجی در runtime بارگیری نشوند. مدل GPU محلی پیش‌نیاز اجباری demo نباشد. پروفایل optional برای inference محلی با نیاز منابع واقعی پس از انتخاب مدل. برنامه با قطع اینترنت بتواند demo قطعی و داده محلی را اجرا کند؛ سرویس بیرونی unavailable برچسب بخورد.

راهنمای optional بسته آفلاین image/wheel/package و مدل دارای مجوز ارائه کن. این بسته به‌دلیل حجم جدا از ZIP سورس است. mirror و proxy را با تنظیمات سازمان پشتیبانی کن، نه bypass پنهانی. secret در build arg، frontend یا log نرود.

Backup، restore، migration rollback/forward recovery، smoke test پس از release، redacted diagnostics bundle و runbook قطع integration تهیه کن. RPO/RTO را پس از نیازسنجی و تست تعیین کن؛ عدد قراردادی از خودت نساز.

## ۲۲. ترتیب پیاده‌سازی و تحویل مرحله‌ای

فاز صفر: audit upstream و منابع، discovery کاتالوگ، ماتریس unknowns، ADR معماری و acceptance matrix. خروجی واقعی کوچک از upstream اجرا و ثبت کن، اگر محیط اجازه می‌دهد.

فاز یک: vertical slice کامل و زیبا با یک مشتری، چند SKU، intent متنی، agent ابزارمحور، quote، approval، رزرو و سفارش demo در PostgreSQL؛ UI فارسی و integration test از ابتدا.

فاز دو: گروه‌سازی، negotiation محدود، solver، نقشه، route و failure handling؛ نمایش رویدادهای واقعی backend.

فاز سه: import کامل‌تر، gateway صوت، adapterهای واقعی، RBAC، audit و shadow mode؛ بدون fabricated integration.

فاز چهار: سناریوهای ارائه، benchmark سه‌گانه، performance، hardening، backup/restore، راهنماها و ZIP.

در پایان هر فاز: چه ساخته شد، چه تست شد، چه محدودیتی مانده و چطور اجرا شود. اگر context تمام شد، پیشرفت و تصمیم‌ها را در فایل ثبت کن و از همان وضعیت ادامه بده. بدون دلیل فنی پروژه را از نو نساز. تغییر stack پس از شروع فقط با ADR موجه.

## ۲۳. فایل‌های الزامی تحویل

حداقل خروجی‌ها با محتوای واقعی:

- `README.fa.md`: معرفی و quickstart دقیق فارسی.
- `GETTING_STARTED.fa.md`: نصب پاک روی دستگاه دیگر.
- `docs/UPSTREAM_AUDIT.fa.md` و `UPSTREAM_COMMIT.txt`.
- `docs/ARCHITECTURE.fa.md`، `docs/ADRs/` و نمودارهای قابل‌خواندن.
- `docs/DATA_DICTIONARY.fa.md` و source-of-truth matrix.
- `docs/CATALOG_IMPORT.fa.md`، نمونه CSV/XLSX و گزارش coverage/conflict.
- `docs/VTT_INTEGRATION.fa.md`: قرارداد شناخته‌شده/ناشناخته، config، diagnostics و آزمون‌ها.
- `docs/ERP_INTEGRATION.fa.md` و نمونه request/response قرارداد پیشنهادی با برچسب روشن.
- `docs/MAPS_AND_ROUTING.fa.md`، مجوز و providerهای فعال.
- `docs/AGENT_TOOLS.fa.md` و schema ابزارها/mandate.
- `docs/SECURITY.fa.md`، RBAC matrix و retention.
- `docs/DEMO_SCRIPT.fa.md` و سناریوهای قابل‌بازتولید.
- `docs/EVALUATION.fa.md`، benchmark config و نتایج واقعی اجراشده.
- `docs/OPERATIONS.fa.md`، backup/restore و incident runbook.
- `docs/PRODUCTION_READINESS.fa.md`: آماده/ناآماده/تست‌نشده با شواهد.
- `BLOCKERS.fa.md`، `PROGRESS.md`، `CHANGELOG.md`، `.env.example` بدون secret.
- OpenAPI export، migrations، lockfileها، Dockerfileها و composeها.
- tests و گزارش اجرای واقعی؛ نمونه test skipped و علت.
- LICENSE/NOTICE/THIRD_PARTY_NOTICES و فهرست وابستگی‌ها یا SBOM.
- اسکریپت‌های bootstrap، seed، reset-demo، test، backup، restore و package.

## ۲۴. ZIP کامل و قابل‌دانلود

در پایان `sayesaman-agentic-marketplace-v1.0.0.zip` از پروژه کامل بساز. ZIP باید سورس web/backend/worker، کد upstream موردنیاز و attribution، assetهای مجاز، داده demo، templateهای import، schema، migrations، تست‌ها، lockfile، compose، env نمونه و تمام راهنماها را داشته باشد.

موارد ممنوع در ZIP: `.env` واقعی، credentials، اطلاعات مشتری واقعی، backup عملیاتی، صوت خصوصی، logs حساس، node_modules، .venv، cache، token و وزن مدل بدون بررسی مجوز. مدل و imageهای حجیم فقط در بسته اختیاری جداگانه؛ راه دریافت و اندازه/نیاز اتصال مستند باشد.

اسکریپت package باید content manifest و SHA256 بسازد و secret scan را اجرا کند. ZIP را در پوشه تازه استخراج و bootstrap/demo smoke test را از آن اجرا کن؛ نبود dependency محلی پنهان و نبود submodule خالی بررسی شود. در گزارش تحویل صریحاً تفاوت «سورس کامل»، «نیاز به دانلود dependency» و «بسته آفلاین» را توضیح بده.

اگر محیط توان ساخت/تست/ضمیمه ZIP ندارد، این محدودیت را صریح اعلام کن، اسکریپت قابل‌اجرا بده و ادعای ZIP ساخته‌شده نکن. لینک نهایی فقط به فایل واقعاً موجود اشاره کند.

## ۲۵. معیار نهایی موفقیت و رفتار ممنوع

خروجی خوب، نرم‌افزاری است که مالک بتواند اجرا کند، سناریو را به مدیر نشان دهد، داده شرکت را وارد کند و فاصله باقی‌مانده تا پایلوت را دقیق بفهمد.

ممنوع:

- تغییر نام پروژه مایکروسافت و اعلام enterprise-ready بدون domain core و آزمون.
- UI متصل به JSON ثابت با ادعای backend/ایجنت زنده.
- مکالمه ازپیش‌نوشته با عنوان مذاکره واقعی مدل.
- قیمت، مشتری، آدرس انبار، endpoint VTT یا KPI ساختگی با عنوان واقعی.
- تبدیل Payment پژوهشی به پرداخت موفق واقعی.
- رزرو/تأیید موفق در UI پیش از موفقیت تراکنش backend.
- پیش‌فرض اجازه مذاکره نامحدود، تغییر اعتبار یا نوشتن در prod.
- بازکردن دسترسی همه agentها به همه بودجه‌ها، مشتری‌ها و داده مالی.
- حذف failure case از دمو برای مثبت نشان‌دادن نتیجه.
- ادعای «بهترین»، «بی‌رقیب»، «اولین در ایران» یا «تضمین صرفه‌جویی» بدون شواهد.

در پاسخ نهایی ساخت، به‌ترتیب بده: فایل ZIP واقعی، دستور نصب، کاربران demo و روش ساخت رمز امن، آنچه واقعاً کار می‌کند، تست‌های اجراشده، integrationهای تأییدشده، integrationهای مسدود، محدودیت‌ها و قدم دقیق بعدی برای پایلوت. هدف، کیفیت فنی و تجربه کاربری قابل‌نمایش با شفافیت کامل است.

اکنون بررسی مخزن را شروع کن، audit و برنامه کوتاه بنویس و بلافاصله vertical slice را پیاده‌سازی کن. تنها با تحویل طرح متوقف نشو. اگر وابستگی بیرونی مسدود شد، کار مستقل را تا تحویل بسته قابل‌اجرا ادامه بده و blocker را ثبت کن.

# پایان دستور ساخت

---

## یادداشت منابع و حدود بررسی تهیه‌کننده پرامپت

این بخش برای عامل سازنده زمینه پژوهش است؛ قوانین محصول بالاتر آمده‌اند.

۱. مخزن و فایل‌های README، TRANSPARENCY، pyproject ریشه و package، docker-compose، docs/concepts/agents.md، docs/concepts/marketplace-protocol.md، customer/models.py و marketplace/shared/models.py از اتصال GitHub خوانده شدند. کد در این مرحله اجرا نشده است.

۲. کاتالوگ در مرورگر پس از اجرای Blazor خوانده شد؛ دسته‌های اصلی و نمونه‌های عالیفرد و شیوا مشاهده شدند. استخراج کامل همه برندها، قیمت و موجودی انجام نشده است. لینک: https://catalog.sayesaman.com/

۳. سایت رسمی شیوا برای ارتباط شرکت با پخش سایه سمن بررسی شد: https://www.shivamfgco.com/shiva1/contact/

۴. داده‌های host/port سرویس VTT فقط از مالک پروژه آمده‌اند. سرویس‌های خصوصی فراخوانی یا صحت‌سنجی نشدند؛ پروتکل و دسترسی ناشناخته است.

۵. اجزای زیر اختیاری‌اند؛ برای نصب هرکدام نسخه، مجوز و سازگاری جاری بررسی شود. لازم نیست همه نصب شوند:

- upstream: https://github.com/microsoft/multi-agent-marketplace
- transparency: https://github.com/microsoft/multi-agent-marketplace/blob/main/TRANSPARENCY.md
- NegMAS، در صورت نیاز واقعی به موتور مذاکره: https://github.com/yasserfarouk/negmas
- smolagents، فقط اگر runtime upstream نیاز را برآورده نکند: https://github.com/huggingface/smolagents
- A2A، مرحله چندسامانه‌ای آینده: https://github.com/a2aproject/A2A
- نمونه مدل قابل‌ارزیابی، نه انتخاب قطعی: https://huggingface.co/Qwen/Qwen3-8B
- نمایش نقشه: https://maplibre.org/maplibre-gl-js/docs/
- پلتفرم نقشه ایرانی برای بررسی قرارداد جاری: https://platform.neshan.org/
- بهینه‌سازی: https://developers.google.com/optimization

این سند مشخصات پیشنهادی محصول است. قابلیت‌های آینده و نیازمندی‌های طراحی را نباید قابلیت آماده مخزن یا سرویس فعلی شرکت تلقی کرد.
