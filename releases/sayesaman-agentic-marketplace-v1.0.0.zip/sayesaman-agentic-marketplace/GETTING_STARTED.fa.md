# نصب پاک و بررسی
۱. ZIP را در پوشه بدون فایل .env قبلی استخراج کنید. manifest و SHA256 را بررسی کنید.
۲. Docker Desktop/WSL2 یا Docker Engine 24+ و Compose v2 را راه‌اندازی کنید. `docker info` و `docker compose version` باید موفق باشند. پورت 8080 باید آزاد باشد؛ `docker compose ps` و خطای bind آن را مشخص می‌کنند. پیش از build از فضای کافی با `df -h` مطمئن شوید. رجیستری‌ها باید از proxy مجاز سازمان قابل دسترسی باشند.
۳. `bash scripts/bootstrap.sh` یا اسکریپت PowerShell را اجرا کنید؛ ساخت image در اولین اجرا آنلاین است. اسکریپت رمز دیتابیس را تصادفی در .env محلی می‌سازد، فایل قبلی را بازنویسی نمی‌کند.
۴. کاربر با دستور README بسازید. فرم ورود هیچ رمز پیش‌فرضی ندارد.
۵. `docker compose ps`، سلامت API و درخواست خرید تا تحویل را بررسی کنید. برای خطا `docker compose logs --tail=100 api worker migrate` را محلی بخوانید؛ اطلاعات حساس را قبل از ارسال حذف کنید.
۶. توقف: `docker compose down` داده را نگه می‌دارد؛ `down -v` داده را حذف می‌کند. اسکریپت reset فقط با فلگ صریح حذف اجرا می‌شود.

## شبکه و آفلاین
runtime دمو نیازی به CDN، مدل GPU، نقشه یا VTT ندارد. font همراه build است. دریافت آنلاین Python/Node/imageها ضروری است. بسته جداگانه آفلاین را با `docker save` و `docker load` روی معماری مقصد بسازید؛ اندازه به image و معماری وابسته است و اینجا اندازه‌ای تضمین نمی‌شود. wheelها با `pip download --require-hashes -r requirements.lock` و package cache با registry مصوب آماده شوند. TLS و checksum را غیرفعال نکنید.

## محیط مدیریت‌شده
در محیط فعلی CA session برای build با secret mount و `-f infra/compose.cloud.yaml` فراهم می‌شود. این CA نباید در ZIP یا image کپی شود. در دستگاه عادی compose.yaml کافی است. secretها در frontend و build arg قرار نمی‌گیرند.
