# اصلاح اتصال Nginx به API
فایل‌های بسته را در پوشه فعلی پروژه استخراج و جایگزین کنید. سپس در PowerShell همان پوشه:

```powershell
docker compose up -d --no-deps --no-build --force-recreate --wait web
```
این دستور فقط سرویس web را بازسازی می‌کند؛ API باید پیش از آن سالم و در حال اجرا باشد.
پس از موفقیت، http://localhost:8080 را با Ctrl+F5 تازه کنید. اگر هنوز خطا وجود داشت، خروجی docker compose logs --tail=30 web api را بررسی کنید.
